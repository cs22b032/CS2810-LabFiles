#include <iostream>

using namespace std;

template <typename T2> class DLL; // Forward definition for compiler.

template <typename T1>
class Node {
private:
    T1 data;
    Node<T1> *next;
Node<T1> *prev;

public:

    Node();

    Node (T1 d);

    void Print();

    friend class DLL<T1>;
};