#include <iostream>
#include "Node.h"

using namespace std;

template <typename T2> class DLL; // Forward definition for compiler.

template <typename T1>
Node<T1>::Node()
{
    next = nullptr;
    prev = nullptr;
}

template <typename T1>
Node<T1>::Node(T1 d): data(d)
{
    next = nullptr;
    prev = nullptr;
}

template <typename T1>
void Node<T1>::Print()
{
    cout << data << " ";
}