#include <iostream>
#include <iomanip>

#include "DLL.h"

using namespace std;

template <typename T2>
DLL<T2>::DLL()
{
    head = new Node<T2>();
    tail = new Node<T2>();
    head -> next = tail;
    head -> prev = nullptr;
    tail->next = nullptr;
    tail -> prev = head;
    first = nullptr;
    last = nullptr;
    len = 0;
}

template <typename T2>
void DLL<T2>::InsertNode(T2 d)
{
    Node<T2>* toAdd = new Node<T2>(d);

    if (len == 0)
    {
        head->next = toAdd;
        tail->prev = toAdd;
        toAdd->next = tail;
        toAdd->prev = head;
        first = toAdd;
        last = toAdd;
    }

    else
    {
        last->next = toAdd;
        tail->prev = toAdd;
        toAdd->next = tail;
        toAdd->prev = last;
        last = last->next;
    }

    len++;
}

template <typename T2>
void DLL<T2>::DeleteMax()
{
    if (len == 0)
        return;

    if (len == 1)
    {
        head->next = tail;
        tail->prev = head;
        
        delete first;

        first = nullptr;
        last = nullptr;
        len--;     
        return;   
    }
    
    Node<T2>* max = first;
    Node<T2>* trav = first;

    while (trav != tail)
    {
        if (max->data < trav->data)
            max = trav;
        trav = trav->next;
    }

    max->prev->next = max->next;
    max->next->prev = max->prev;

    if (max == first)
        first = first->next;

    if (max == last)
        last = last->prev;

    delete max;
    len--;
    return;
}

template <typename T2>
T2 DLL<T2>::SumAll()
{
    T2 sum = T2();
    if (len == 0)
        return sum;
    
    Node<T2>* trav = first;
    while (trav != tail)
    {
        sum = sum + trav->data;
        trav = trav->next;
    }

    return sum;
}

template <typename T2>
unsigned int DLL<T2>::Length()
{
    return len;
}

template <typename T2>
void DLL<T2>::updateKpos(int k, T2 newdata)
{
    if (k > 0 && k <= len)
    {
        int i = 1;
        Node<T2>* trav = first;

        while (i < k)
        {
            trav = trav->next;
            i++;
        }

        trav->data = newdata;
        return;
    }

    else
    {
        throw std::out_of_range("OOR");
    }
}

template <typename T2>
void DLL<T2>::printList()
{
    if (len == 0)
    return;

    Node<T2>* trav = first;

    while (trav != tail)
    {
        trav->Print();
        trav = trav->next;
    }

    cout << endl;
}