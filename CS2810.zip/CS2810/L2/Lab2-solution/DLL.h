#include <iostream>
#include "Node.cpp"

using namespace std;

template <typename T2>

class DLL {

private:
    Node<T2> *first, *last, *head, *tail;
    unsigned int len;

public:
    DLL();

    void InsertNode(T2);

    void DeleteMax();

    T2 SumAll();

    unsigned int Length();

    void updateKpos(int, T2);

    void printList();
};