#include <iostream>
#include "DLL.cpp"

using namespace std;

class ComplexNum
{
private:
    double real;
    double imag;

public:
    ComplexNum()
    {
        real = 0.0;
        imag = 0.0;
    }

    ComplexNum(double a)
    {
        real = a;
        imag = 0.0;
    }

    ComplexNum(double a, double b)
    {
        real = a;
        imag = b;
    }

    ComplexNum(const ComplexNum& C1)
    {
        this->real = C1.real;
        this->imag = C1.imag;
    }

    ComplexNum operator+ (ComplexNum C2)
    {
        ComplexNum C3(this->real + C2.real, this->imag + C2.imag);
        return C3;
    }

    ComplexNum operator- (ComplexNum C2)
    {
        ComplexNum C3(this->real - C2.real, this->imag - C2.imag);
        return C3;
    }

    ComplexNum operator* (ComplexNum C2)
    {
        ComplexNum C3;
        C3.real = (this->real * C2.real) - (this->imag * C2.imag);
        C3.imag = (this->real * C2.imag) + (this->imag * C2.real);
        return C3;
    }

    void operator= (ComplexNum C2)
    {
        real = C2.real;
        imag = C2.imag;
    }

    ComplexNum operator/ (ComplexNum C2)
    {
        if (C2.real == 0.0 && C2.imag == 0.0)
        {
            ComplexNum C3(1, 1);
            return C3;
        }

        double mag = (C2.imag * C2.imag) + (C2.real * C2.real);
        ComplexNum C3(C2.real, -C2.imag);

        ComplexNum C4 = *this * C3;
        C4.real /= mag;
        C4.imag /= mag;

        return C4;
    }

    bool operator< (ComplexNum C2)
    {
        if (real < C2.real || (real == C2.real && imag < C2.imag))
        return true;
        else
        return false;
    }

    friend ostream& operator<< (ostream& os, const ComplexNum C1)
    {
        os << (long long int)C1.real << " " << (long long int)C1.imag;
        return os;
    }
};

int main()
{
    int typechoice;
    cin >> typechoice;

    switch (typechoice)
    {
        case 1:
        {
            DLL<int>* list = new DLL<int>();
            int element;
            int total;

            int N;
            cin >> N;

            for (int i = 0; i < N; i++)
            {
                cin >> element;
                list->InsertNode(element);
            }

            char ch;
            cin >> ch;

            while (ch != 'X')
            {
                switch (ch)
                {
                    case 'I':
                    {
                        cin >> element;
                        list->InsertNode(element);
                        break;
                    }

                    case 'U':
                    {
                        int k;
                        cin >> k;
                        cin >> element;

                        try
                        {
                            list->updateKpos(k, element);
                        }
                        catch(const std::out_of_range& e)
                        {
                            cout << e.what() << '\n';
                        }
                        
                        break;
                    }

                    case 'D':
                    {
                        list->DeleteMax();
                        break;
                    }

                    case 'S':
                    {
                        cout << list->SumAll() << endl;
                        break;
                    }

                    case 'L':
                    {
                        cout << list->Length() << endl;
                        break;
                    }

                    case 'P':
                    {
                        list->printList();
                        break;
                    }

                    case 'X':
                    {
                        break;
                    }
                }

                cin >> ch;
            }

            break;
        }

        case 2:
        {
            DLL<double>* list = new DLL<double>();
            double element;
            double total;
            int N;
            cin >> N;

            for (int i = 0; i < N; i++)
            {
                cin >> element;
                list->InsertNode(element);
            }

            char ch;
            cin >> ch;

            while (ch != 'X')
            {
                switch (ch)
                {
                    case 'I':
                    {
                        cin >> element;
                        list->InsertNode(element);
                        break;
                    }

                    case 'U':
                    {
                        int k;
                        cin >> k;
                        cin >> element;

                        try
                        {
                            list->updateKpos(k, element);
                        }
                        catch(const std::out_of_range& e)
                        {
                            cout << e.what() << '\n';
                        }
                        
                        break;
                    }

                    case 'D':
                    {
                        list->DeleteMax();
                        break;
                    }

                    case 'S':
                    {
                        cout << list->SumAll() << endl;
                        break;
                    }

                    case 'L':
                    {
                        cout << list->Length() << endl;
                        break;
                    }

                    case 'P':
                    {
                        list->printList();
                        break;
                    }

                    case 'X':
                    {
                        break;
                    }
                }

                cin >> ch;
            }

            break;
        }

        case 3:
        {
            DLL<ComplexNum>* list = new DLL<ComplexNum>();
            ComplexNum element;
            ComplexNum total;
            double x, y;

            int N;
            cin >> N;

            for (int i = 0; i < N; i++)
            {
                cin >> x >> y;
                element = *(new ComplexNum(x, y));
                list->InsertNode(element);
            }

            char ch;
            cin >> ch;

            while (ch != 'X')
            {
                switch (ch)
                {
                    case 'I':
                    {
                        cin >> x >> y;
                        element = *(new ComplexNum(x, y));
                        list->InsertNode(element);
                        break;
                    }

                    case 'U':
                    {
                        int k;
                        cin >> k;
                        cin >> x >> y;
                        element = *(new ComplexNum(x, y));
                        

                        try
                        {
                            list->updateKpos(k, element);
                        }
                        catch(const std::out_of_range& e)
                        {
                            cout << e.what() << '\n';
                            break;
                        }
                        
                        break;
                    }

                    case 'D':
                    {
                        list->DeleteMax();
                        break;
                    }

                    case 'S':
                    {
                        cout << list->SumAll() << endl;
                        break;
                    }

                    case 'L':
                    {
                        cout << list->Length() << endl;
                        break;
                    }

                    case 'P':
                    {                        
                        list->printList();
                        break;
                    }

                    case 'X':
                    {
                        break;
                    }
                }

                cin >> ch;
            }
            
            break;
        }
    }
}