// CS2810 Lab 1 Test case generator
// g++ -o testgen-lab1 testgen-lab1.cpp
// Run as: ./testgen-lab2 N Q B E 1/2/3 > input1.txt
// Example: ./testgen-lab2 10 5 -500 500 3
// To save the output in a file called say input1.txt
// B (and E) is the smallest (largest) possible value of real/imag
// 1: int; 2: double; 3: ComplexNum

#include<iostream>
#include<string>
#include<vector>
#include<cstdlib>
#include<ctime>
#include<iomanip>

using namespace std;

int main(int argc, char **argv)
{
  int N = stoi(argv[1]);
  int Q = stoi(argv[2]);
  int B = stoi(argv[3]);
  int E = stoi(argv[4]);
  int instance_type = stoi(argv[5]); // 1: int; 2: double; 3: ComplexNum
  
  std::srand(std::time(nullptr));

  if ((instance_type > 0) && (instance_type <= 3))
    cout << instance_type << endl;
  else
    exit(-1);			// Exit program with error code of -1
  
  int range = (E - B + 1);

  cout << N << endl;
  for (int i = 0; i < N; i++)
    {
      int val, re, im;
      double d;

      if (instance_type == 1)
	{
	  val = B + (rand() % range);
	  cout << val << endl;
	}

      if (instance_type == 2)
	{
	  d = B + (drand48()*range);
	  cout <<  setw(15) << d << endl;
	}
	    
      if (instance_type == 3)
	{
	  re = B + (rand() % range);
	  im = B + (rand() % range);
	  cout << re << " " << im << endl;
	}
    }

  //  cout << Q << endl;
      
  for (int q = 0; q < Q; q++) 
    {
      int i, j, k, m;
	
      int val, re, im;
      double d;

      m = rand() % 6;
      switch (m)
	{
	case 0: 		// Insert
	  N++;
	  if (instance_type == 1)
	    {
	      val = B + (rand() % range);
	      printf("%c %d\n", 'I', val);
	    }
	  
	  if (instance_type == 2)
	    {
	      d = B + (drand48()*range);
	      printf("%c %0.6lf\n", 'I', d);
	    }
			    
	  if (instance_type == 3)
	    {
	      re = B + (rand() % range);
	      im = B + (rand() % range);
	      printf("%c %d %d\n", 'I', re, im);
	    }

	  break;
	case 1: 		// Update
	  k = 5 + (rand() % N);
	  
	  if (instance_type == 1)
	    {
	      val = B + (rand() % range);
	      printf("%c %d %d\n", 'U', k, val);
	    }
	  
	  if (instance_type == 2)
	    {
	      d = B + (drand48()*range);
	      printf("%c %d %0.6lf\n", 'U', k, d);
	    }
			    
	  if (instance_type == 3)
	    {
	      re = B + (rand() % range);
	      im = B + (rand() % range);
	      printf("%c %d %d %d\n", 'U', k, re, im);
	    }

	  break;
	  
	case 2: 		// DeleteMax
	  printf("%c\n", 'D');
	  break;
	  
	case 3: 		// SumAll
	  printf("%c\n", 'S');
	  break;
	  
	case 4: 		// print
	  printf("%c\n", 'P');
	  break;
	  
	case 5: 		// Length
	  printf("%c\n", 'L');
	  break;
	}
    }

  printf("%c\n", 'X');
}
