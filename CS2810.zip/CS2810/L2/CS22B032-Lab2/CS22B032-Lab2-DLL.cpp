#include <iostream>
#include <cassert>
#include "CS22B032-Lab2-DLL.h"
using namespace std;

template <typename T2>
DLL<T2>::DLL()
    {
        first = new Node<T2>();
        last = new Node<T2>();
        head = new Node<T2>();
        tail = new Node<T2>();
        //cout << len << endl;
        //default constructor without argument
        //if(head->next == nullptr ) cout << len << endl;
        head -> next = tail;
        tail -> prev = head;
        first = head;
        last = tail;
        len = 0;
        //cout << len << endl;
    }

template <typename T2>
void DLL<T2>::updateKpos(int i, T2 d)
    {
        Node<T2> *temp = new Node<T2>();
        if(i > len || i < 1) throw out_of_range("OOR");
        temp = head;
        for(int ii = 0; ii< i ;ii++)
        {
            temp = temp->next;
        }
        temp ->data = d;
    }

// Create a Node with data item as d; insert this Node into the end of
// this object Linked List.

template <typename T2>
void DLL<T2>::InsertNode(T2 d)
    {
        //break previous linkage and add new node
        Node<T2> *temp = new Node<T2>(d);
        temp -> next = tail;
        temp -> prev = tail ->prev;
        tail -> prev ->next = temp;
        tail ->prev = temp;
        len++;
        //cout << len << endl;
    }

template <typename T2>
unsigned int DLL<T2>::Length()
    {
        return len;
    }

template <typename T2>
void DLL<T2>::printList()
    {
        Node<T2> *temp = new Node<T2>();
        temp = head -> next;
        while(temp != tail)
        {
            temp->Print();
            temp = temp ->next;
        }
        cout << endl;
    }


template <typename T2>
T2 DLL<T2>::SumAll()
    {
        Node<T2> *temp = new Node<T2>();
        temp = head -> next;
        T2 sum = T2();
        while (temp != tail)
        {
            sum = sum + temp->data;
            temp = temp ->next;
        }
        return sum;
    }

template <typename T2>
void DLL<T2>::deleteNode(Node<T2> *d)
    {
        if ((head  == d) || (tail == d)) 
        {
            return;
        }
        Node<T2> *current, *previous = nullptr;
    // Traverse the list to
    // find the node to be deleted.
        current = head->next;		// First node with valid data.
        while (current != d)
            current = current->next;

    //change the next pointer
    // of the previous node.
        previous = d->prev;
    
        previous->next = d->next;
        (d->next)->prev = d->prev;
    
        len--;
    
    // Delete the node
        delete d;
    }

template <typename T2>
void DLL<T2>::DeleteMax()
    {
        Node<T2> *temp = new Node<T2>();
        temp = head -> next;
        Node<T2> *maxx = new Node<T2>();
        //cout << tail->data << endl;
        for(int i = 1 ; i<= len; i++)
        {
            if(maxx ->data  < temp ->data )
            {
                maxx = temp;
            }
            temp = temp -> next;
        }
        //cout << maxx ->data << endl;
        deleteNode(maxx);
    }