// Roll Number: CS22B032
// Name: ANKIT RAJ
// CS2810 Lab Number: 02
// Date: 30 /01, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include<bits/stdc++.h>
#include "ComplexNum.cpp"
using namespace std;
#include "CS22B032-Lab2-DLL.h"


int main()
{
    // 1 for int 
    // 2 for double
    // 3 for complexnum
    int type;
    cin >> type;
    // how many nodes
    int N;
    cin >> N;
    //for int 
    if(type == 1)
    {
        DLL<int> d1;
        for(int i = 0; i<N; i++)
        {
            int a;
            cin >> a;
            d1.InsertNode(a);
        }
        char Q;
        cin >> Q;
        //query
        while(Q != 'X')
        {
            if(Q == 'I')
            {
                int data;
                cin >> data;
                d1.InsertNode(data);
            }
            else if(Q == 'U')
            {
                try
                {
                    int k, ind;
                    cin >> k >> ind;
                    d1.updateKpos(k, ind); //check if error
                }
                catch(std :: out_of_range &e)
                {
                    std :: cerr << e.what() << endl;
                }
            }
            else if(Q == 'D')
            {
                d1.DeleteMax();
            }
            else if(Q == 'S')
            {
                cout << d1.SumAll() << endl;
            }
            else if(Q == 'L')
            {
                cout << d1.Length() << endl;
            }
            else if(Q == 'P')
            {
                d1.printList();
            }
            cin >> Q;
        }
    }
    //for double
    else if(type == 2)
    {
        DLL<double> d1;
        for(int i = 0; i<N; i++)
        {
            double a;
            cin >> a;
            d1.InsertNode(a);
        }
        //query
        char Q;
        cin >> Q;
        while(Q != 'X')
        {
            if(Q == 'I')
            {
                double data;
                cin >> data;
                d1.InsertNode(data);
            }
            else if(Q == 'U')
            {
                try
                {
                    int k;
                    double ind;
                    cin >> k >> ind;
                    d1.updateKpos(k, ind); //check if error
                }
                catch(std :: out_of_range &e)
                {
                    std :: cerr << e.what() << endl;
                }
            }
            else if(Q == 'D')
            {
                d1.DeleteMax();
            }
            else if(Q == 'S')
            {
                cout << d1.SumAll() << endl;
            }
            else if(Q == 'L')
            {
                cout << d1.Length() << endl;
            }
            else if(Q == 'P')
            {
                d1.printList();
            }
            cin >> Q;
        }
    }
    //for complexnum
    else
    {
        DLL<ComplexNum> d1;
        for(int i = 0; i<N; i++)
        {
            double a, b;
            cin >> a >> b;
            ComplexNum com(a, b);
            d1.InsertNode(com);
        }
        //query
        char Q;
        cin >> Q;
        while(Q != 'X')
        {
            if(Q == 'I')
            {
                double a1;
                double b1;
                cin >> a1 >> b1;
                d1.InsertNode(ComplexNum(a1, b1));
            }
            else if(Q == 'U')
            {
                try
                {
                    double k;
                    int ind;
                    cin >> k >> ind;
                    d1.updateKpos(k, ind); //check if error
                }
                catch(std :: out_of_range &e)
                {
                    std :: cerr << e.what() << endl;
                }
            }
            else if(Q == 'D')
            {
                d1.DeleteMax();
            }
            else if(Q == 'S')
            {
                cout << d1.SumAll() << endl;
            }
            else if(Q == 'L')
            {
                cout << d1.Length() << endl;
            }
            else if(Q == 'P')
            {
                d1.printList();
            }
            cin >> Q;
        }
    }
}
