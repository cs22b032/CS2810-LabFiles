#include <iostream>
#include <cassert>
#include "CS22B032-Lab2-Node.h"
using namespace std;

#pragma once
template <typename T2>
class DLL {
private:
    Node<T2> *first, *last, *head, *tail;
    unsigned int len;

public:
  
    DLL();
    void InsertNode(T2 d);
    void printList();
    T2 SumAll();
    void updateKpos(int, T2);
    void DeleteMax();
    unsigned int Length();
    void deleteNode(Node<T2>*);
};

#include "CS22B032-Lab2-DLL.cpp"