#include <iostream>
#include <cassert>
using namespace std;

#pragma once
template <typename T2> class DLL; // Forward definition for compiler.

template <typename T1>
class Node {

private:

  T1 data;
  Node<T1> *next;
  Node<T1> *prev;

public:

  Node();

  Node(T1 d);

  void Print();
  
    friend class DLL<T1>;

};

#include "CS22B032-Lab2-Node.cpp"