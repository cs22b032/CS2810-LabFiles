// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 4
// Date: 13/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include "Course.h"
#include "Person.h"
#include "Faculty.h"
#include "RegFaculty.h"
#include "VisFaculty.h"
#include "Student.h"
using namespace std;
// Reg. Faculty: 1000 - 1999
// Vis. Faculty: 2000 - 2999
// Students: 3000 - 9999
const unsigned int PERSONS = 1000;

int main()
{
	//all persons including everyone
	vector<Person *> AllPersons;
	unsigned int *S;
	//id of persons
	unsigned int id;
	cin >> id;
	while (id != -1)
	{
		//break if id = -1
		string name;
		cin >> name;
		if (id >= 1000 && id <= 1999)
		{
			// Reg. Faculty: 1000 - 1999
			int N;
			cin >> N;
			//courses taught 
			vector<Course> Taught;
			for (int i = 0; i < N; i++)
			{
				int cors;
				cin >> cors;
				//creating constructor
				Taught.push_back(Course(cors, 0));
			}
			unsigned int J, C, A;
			cin >> J >> C >> A;
			// using malloc data
			S = new unsigned int [A];
			for (int i = 0; i < A; i++)
			{
				cin >> S[i];
			}
			//for reg faculty , creating constructor
			AllPersons.push_back((RegFaculty *)new RegFaculty(id, name, rfa, Taught, J, C, S, A));
			// check if A is correct
		}

		else if (id >= 2000 && id <= 2999)
		{
			// Vis. Faculty: 2000 - 2999
			int N;
			cin >> N;
			//courses taught 
			vector<Course> Taught;
			for (int i = 0; i < N; i++)
			{
				int cors;
				cin >> cors;
				//creating constructor
				Taught.push_back(Course(cors, 0));
			}
			unsigned int J, C, hid;
			cin >> J >> C>> hid;
			//pushing visfaculty
			AllPersons.push_back((VisFaculty *)new VisFaculty(id, name, vfa, Taught, J, C, hid));

		}

		else if (id >= 3000 && id <= 9999)
		{
			// Students: 3000 - 9999
			int N;
			cin >> N;
			//courses completed 
			vector<Course> Taken;
			for (int i = 0; i < N; i++)
			{
				int cors, gp;
				cin >> cors >> gp;
				//pushing course constructor
				Taken.push_back(Course(cors, gp));
			}
			unsigned int fid;
			cin >> fid;
			//pushing student
			AllPersons.push_back((Student *)new Student(id, name, st, Taken, fid));
			//cout << 3 << endl;
		}
		cin >> id;
	}

	char Q;
	cin >> Q;
	//query
	while (Q != 'X')
	{
		unsigned int sid, fid, cid;

		switch (Q)
		{
			//for each query
			// Print name of host faculty given vid
		case 'H':
		{
			cin >> cid;
			bool flag = false;
			for(auto per : AllPersons){
				//per->Print();        ///
				if(per->GetId() == cid){
					VisFaculty *vifc = (VisFaculty *)per;
					//printing host
					cout << vifc->GetHost() << " ";
					for(auto rper : AllPersons){
						//checking further to print name 
						if(rper->GetId() == vifc->GetHost()){
							cout << rper->GetName() << endl;
							flag = true;
							break;
						}
					}
					
				} // End 'H' query
				if(flag) break;
			}
			break;
		}
		case 'J': // Student with highest CGPA
		{
			unsigned int maxcg;
			unsigned int max_stud_id;

			maxcg = 0;
			for (unsigned int i = 0; i < AllPersons.size(); i++)
			{
				//only for students
				if (AllPersons[i]->GetPType() == st)
				{
					//typecasting
					Student *stud = (Student *)AllPersons[i];
					//taking maximum
					maxcg = max(maxcg, stud->GetCG());
				}
			}
			for (unsigned int i = 0; i < AllPersons.size(); i++){
				//only for students
				if(AllPersons[i]->GetPType() == st){
					Student * stdr = (Student * )AllPersons[i] ;
					//checking for max cg
					if(stdr->GetCG() == maxcg){
					cout << stdr->GetId() << endl;
					break;
					}
				}
			}
			break; // End 'J' query
		}
		case 'U': // Change VisFac to Reg
		{
			cin >> sid;
			for (unsigned int i = 0; i < AllPersons.size(); i++){
				//only for studenets
				if (AllPersons[i]->GetPType() == st) {
					//typecating to std
					Student * stdr = (Student * )AllPersons[i];
					if(stdr->GetId() == sid)
					{
						//checkhing sid
						unsigned int j;
						for (j = 0; j < AllPersons.size(); j++){
							if(stdr->GetFacad()==AllPersons[j]->GetId())
							{
								//printing if yes or no
								cout << ((RegFaculty*)AllPersons[j])->isAdvisor(sid) << endl;
								break;
							}
						}
							//if not printed print 0
						if(j==AllPersons.size()) cout << 0 <<endl;
					}
				}
			}
			break; // End 'U' query
		}
			
		} // End While
		cin >> Q;
		//take input again
	}
}
