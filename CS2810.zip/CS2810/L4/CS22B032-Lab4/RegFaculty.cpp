// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 4
// Date: 13/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "RegFaculty.h"

using namespace std;

//  unsigned int *advisees;
//  int numadv;
RegFaculty ::RegFaculty() : Faculty()
{
    *advisees = 0;
    numadv = 0;
}
//  Faculty(unsigned int sad, string naam, persontype p,
//	  vector<Course> C, unsigned int jo, unsigned int co);

RegFaculty::RegFaculty(unsigned int sad, string naam, persontype p,
                       vector<Course> C, unsigned int jo, unsigned int co,
                       unsigned int S[], unsigned int nadv) : Faculty(sad, naam, p, C, jo, co)
{
    advisees = S;
    numadv = nadv;
}
// Assigned respectively.
// gradepoint field is set to 0 for Faculty's Course objects
// and is not used.

bool RegFaculty ::isAdvisor(unsigned int sid)
{
    for (int i = 0; i < NumAdvisees(); i++)
    {
        if (advisees[i] == sid)
            return true;
    }
    return false;
}

unsigned int RegFaculty ::NumAdvisees()
{
    return numadv;
}

void RegFaculty::Print()
{
    Faculty ::Print();
    cout << endl;
} // Prints id, name, journals, conferences
  // on one line separated by a space.