// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 3
// Date: 06/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include "Student.h"
using namespace std;

Student ::Student() : Person()
{
    facad = 0;
}

Student ::Student(unsigned int sad, string naam, persontype p,
                  vector<Course> C, unsigned int fid) : Person(sad, naam, p)
{
    CoursesTaken = C;
    facad = fid;
} // Assigned respectively.

vector<Course> Student::GetCourses()
{
    return CoursesTaken;
} // Returns copy of courses vector

unsigned int Student::GetCG()
{
    int ans = 0;
    for (auto a : CoursesTaken)
    {
        ans += a.GetGrade();
    }
    ans /= CoursesTaken.size();
    return ans;
} // average value

unsigned int Student::GetFacad()
{
    return facad;
} // Returns  copy of Facad ID of student.

void Student::Print()
{
    Person::Print();
    cout << " " << GetCG() << " " << facad << endl;
} // Prints sadhar, name, cpga details of student, followed by facad's id and name.