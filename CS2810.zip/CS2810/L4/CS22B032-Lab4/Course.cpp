// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 4
// Date: 13/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate

#include <iostream>
#include <cassert>
#include "Course.h"

using namespace std;

Course :: Course() { //default constructer
    cid = 0;
    gradepoint = 0;
}
//constructor as given
Course :: Course(unsigned int id = 0, unsigned int grade = 0){
    if(grade <= 10 && grade >= 4) gradepoint = grade;
    if(id <= 100 && id >= 999) cid = id;
}
//return cid
unsigned int Course:: GetCid() {
    return cid;
}
//return grade
unsigned int Course:: GetGrade() {
    return gradepoint;
}
//setting grade
void Course::SetGrade(int g){
    if(g <= 10 && g >= 4) gradepoint = g;
}
//for printing
void Course :: Print(){
    cout << cid << " " << gradepoint;
}