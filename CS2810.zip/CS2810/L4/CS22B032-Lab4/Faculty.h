// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 4
// Date: 13/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include "Person.h"
#include "Course.h"
#pragma once
class Faculty : public Person
{

private:
  vector<Course> CoursesTaught;
  unsigned int journals, confs;

public:
  Faculty();

  Faculty(unsigned int sad, string naam, persontype p,
          vector<Course> C, unsigned int jo, unsigned int co);
  // Assigned respectively.
  // gradepoint field is set to 0 for Faculty's Course objects
  // and is not used.

  unsigned int GetJournals();  // Returns journals value
  unsigned int GetConfs();     // Returns confs value
  vector<Course> GetCourses(); // Returns ref. to courses vector

  void Print(); // Prints id, name, journals, conferences
                // on one line separated by a space.

  ~Faculty()
  {
  }
};
