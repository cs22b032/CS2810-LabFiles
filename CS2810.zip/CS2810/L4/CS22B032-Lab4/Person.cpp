// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 4
// Date: 13/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "Person.h"

using namespace std;

Person :: Person(){
    sadhar = 0;
    name = "";
    ptype = none;
}
  
Person :: Person(unsigned int sad, string naam, persontype p){
    sadhar = sad;
    name = naam;
    ptype = p;
} // assigned respectively

string Person :: GetName(){
    return name;
}

void Person :: SetName(string naam){
    name = naam;
}

persontype Person :: GetPType(){
    return ptype;
}

void Person :: SetPType(persontype p){
    ptype = p;
}

unsigned int Person :: GetId(){
    return sadhar;
}

void Person :: SetId(unsigned int sad){
    sadhar = sad;
}

void Person :: Print(){
    cout << sadhar << " " << name ;
} // Prints id and name separated by a blank space on one line.
