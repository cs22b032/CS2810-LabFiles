rm -rf results
rm -rf actual_outputs