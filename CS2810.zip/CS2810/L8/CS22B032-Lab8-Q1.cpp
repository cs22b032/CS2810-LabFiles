// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 08
// Date: 02/04, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include <getopt.h>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include "GraphAdjList.h"

using namespace std;

// valid long options code with the values the
// variables will be mapped to after argument parsing

// ./<executable> --arg1 in.txt --arg2 prim --arg3 1 {fileName='in.txt', alg='prim', node=1}
// ./<executable> --arg2 kruskal --arg1 in.txt --arg3 2 {fileName='in.txt', alg='kruskal', node=2}
// ./<executable> --arg3 2 --arg1 in.txt {fileName='in.txt', alg='prim', node=2} [default value of alg is 'prim']
// ./<executable> --arg1 in.txt --arg3 2 --arg2 xyz {fileName='in.txt', alg='prim', node=2}


// ./<executable> --in input01.txt --out output01.txt --alg dij --src s --dest d
// (OR)
// ./<executable> --in input01.txt --out output01.txt --alg flwa --src s --dest d
// ./<executable> --dest d --src s --out output01.txt --in input01.txt

int main(int argc, char* argv[]) {
	// mention the default values of the following variables here
	string a,b,c;
	int a1, a2;
	int check;

	// change 'arg1', 'arg2', 'arg3' according to the name of the argument
	struct option longopts[] = {
		{"in", required_argument, NULL, 'a'}, 
		{"out", required_argument, NULL, 'b'},
		{"alg", required_argument, NULL, 'c'},
    {"src", required_argument, NULL, 'd'},
    {"dest", required_argument, NULL, 'e'},
		
    };

    // parse arguments
    while(1){
    	// const int opt = getopt_long(argc, argv, "", longopts, 0);    
    	const int opt = getopt_long(argc, argv, "a:b:c:d:e", longopts, 0);
    	// unexpected error or done parsing
    	if (opt == -1){
    		break;
    	}

    	switch (opt){
    	case 'a':
    		cout << "in: " << optarg << endl;
    		// the value of the argument is stored in 'optarg' variable
    		a = optarg;
    		break;
    	case 'b':
    		cout << "out: " << optarg << endl;
    		b = optarg;
    		break;
    	case 'c':
    		cout << "arg3: " << optarg << endl;
    		c=optarg;
    		if(c=="fwla") check=0;
    		else check=1;
    		break;
    	case 'd':
    	  a1=atoi(optarg);
        break;
    	case 'e':
    		a2=atoi(optarg);
        break;
    	case '?':
    		abort ();
        break;
		default:
			abort ();
    	}
    }

    cout << "argument parsing done!\n" << endl;

    // set alg to 'prim' if invalid name is passed to --alg
    // if(alg != "flwa" && alg != "dij"){
    // 	alg = "dij";
    // }

    // cout << "fileName: " << fileName << endl;
    // cout << "alg: " << alg << endl;
    // cout << "node: " << node << endl;
    
  ifstream ifile(a);
  ofstream ofile(b, ios::out);
  int N;

  //cout << argv[1] << " " << N << endl;
  ifile >> N;
  GraphAdjList G(N);
  
  int src, dest, weight;
// cout << "dfj" << endl;
  while (ifile >> src >> dest >> weight)
    {
      G.addedge(src, dest, weight);
	  G.addedge(dest, src, weight);
      // Make sure that bidirectional edges are added.
    }
      // cout << "Fr" << endl;

  // Change this to long option
  if(check){
	auto [SPath, tcost] = G.dijkstra(a1,a2 );
	while (!SPath.empty())
    {
      int n;
      n = SPath.top();
      ofile << n << " ";
      SPath.pop();
    }

  ofile << "; " << tcost << endl;
  }
  else{
  auto [SPath1, tcost1] = G.flowarsh(a1, a2);

  while (!SPath1.empty())
    {
      int n;
      n = SPath1.top();
      ofile << n << " ";
      SPath1.pop();
    }

  ofile << "; " << tcost1 << endl;
  }
	return 0;
}

