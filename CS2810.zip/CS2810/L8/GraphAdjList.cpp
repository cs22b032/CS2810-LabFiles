#include "GraphAdjList.h"
#define inf 10000000
#define ipair pair<int, pair<int, int>>
GraphAdjList::GraphAdjList(int nc, int ec) : Graph(nc, ec)
{
    AdjList.resize(nc);
    indegree.resize(nc);
}

void GraphAdjList ::addedge(int src, int dest, int weight)
{
    int V = getnodecount();
    if (src >= V || dest >= V || src < 0 || dest < 0)
        return;
    if (src == dest)
        return; // if simple graph
    auto [it, success] = AdjList[src].insert(make_pair(dest, weight));
    auto [it2, success2] = AdjList[dest].insert(make_pair(src, weight));
    if (success)
        indegree[src]++;
    if (success2)
        indegree[dest]++;
    if (success && success2)
        setedgecount(getedgecount() + 1);
    // cout << "Adding edge " << "( " << src <<" ," << dest <<" )  with weight "<< weight << endl;
}

void GraphAdjList ::printgraph()
{

    cout << "Node : " << getnodecount() << " and Edges : " << getedgecount() << endl;
    for (int i = 0; i < AdjList.size(); i++)
    {
        cout << "Node : " << i << "| "
             << "has degree " << indegree[i] << " ";
        for (auto items : AdjList[i])
            cout << "(" << items.first << ", " << items.second << ") ";
        cout << endl;
    }
}

void GraphAdjList ::deledge(int src, int dest)
{
    int V = getnodecount();
    if (src >= V && dest >= V && src < 0 && dest < 0)
        return;
    auto it = AdjList[src].find(dest);
    auto it1 = AdjList[dest].find(src);
    if (it != AdjList[src].end())
    {
        AdjList[src].erase(dest);
        indegree[src]--;
    }
    if (it1 != AdjList[dest].end())
    {
        AdjList[dest].erase(src);
        indegree[dest]--;
        setedgecount(getedgecount() - 1);
    }
}

std::tuple<stack<int>, int> GraphAdjList::dijkstra(int src, int dest)
{
    stack<int> path;
    path.push(dest);
    // cout << src  << endl;
    int V = getnodecount();
    // if(src >= V && src < 0) return;
    // if(dest >= V && dest < 0) return;
    vector<int> dist(V, inf);
    dist[src] = 0;
    vector<int> prev(V);
    prev[src] = -1;
    // distance , present_node weight
    priority_queue<ipair, vector<ipair>, greater<ipair>> EdgePQ;
    vector<bool> visited(V, false);
    int visi = 0;

    for (auto Edg : AdjList[src])
    {
        int des = Edg.first;
        int wt = Edg.second;
        EdgePQ.push(make_pair(wt, make_pair(des, src)));
        prev[des] = src;
        dist[des] = wt;
    }
    visited[src] = true;
    visi++;
    // EdgePQ.push(make_pair(wt, make_pair(src, dest)));
    while (visi != V)
    {
        auto item = EdgePQ.top();
        EdgePQ.pop();
        int new_node = item.second.first;
        int des_node = item.first;
        int pre = item.second.second;

        if (!visited[new_node])
        {
            for (auto Edg : AdjList[new_node])
            {
                int des = Edg.first;
                int wt = Edg.second;
                if (dist[des] > dist[new_node] + wt)
                {
                    dist[des] = dist[new_node] + wt;
                    EdgePQ.push(make_pair(dist[des], make_pair(des, src)));
                    prev[des] = new_node;

                }
            }
            visi++;
            visited[new_node] = true;
        }
    }
    int sr = prev[dest];
    while(sr != src)
    {
        path.push(sr);
        sr = prev[sr];
    }
    path.push(src);
    // cout << dist[dest] << endl;
    std:: tuple<stack<int>, int>  ans = make_tuple(path, dist[dest]);
    return ans;
}

  std::tuple< stack<int>, int> GraphAdjList:: flowarsh (int src, int dest){

    int V = getnodecount();

    vector<vector<int>> mat(V, vector<int>(V, 10000000));
    vector<vector<int>> parent(V, vector<int>(V, -1));
    for(int i = 0; i<V; i++){
        for (auto Edg : AdjList[i])
        {
            parent[i][Edg.first] = i;
        }
    }
    for(int k = 0; k < V; k++){
         for(int j = 0; j < V; j++)
          for(int i = 0; i < V; i++){
            if(mat[i][k] + mat[k][j] < mat[i][j]){
                mat[i][j] = mat[i][k] + mat[k][j];
                parent[i][j] = parent[k][j];
            }
          }
    }
    int j = dest;
    stack<int> path;
    path.push(dest);
    while(parent[src][j]!= src){
        j = parent[src][j];
        path.push(j);
    }
    path.push(src);
    // cout << dist[dest] << endl;
    std:: tuple<stack<int>, int>  ans = make_tuple(path, mat[src][dest]);
    return ans;
  }
// std::priority_queue<int> pq; -> for maxheap
// priority_queue <int, vector<int>, greater<int>> gq; -> for minheap

// int main()
// {
//     GraphAdjList G(5);

//     G.addedge(0, 1, 2);
//     G.addedge(0, 2, 5);
//     G.addedge(0, 3, 7);
//     G.addedge(0, 4, 1);
//     G.addedge(0, 4, 1);
//     G.addedge(1, 1, 1);
//     G.addedge(1, 2, 3);
//     G.addedge(1, 3, 4);
//     G.addedge(2, 4, 7);
//     G.addedge(3, 4, 8);
//     G.addedge(2, 3, 10);
//     G.addedge(4, 1, 9);
//     G.deledge(2, 3);
//     G.deledge(1, 4);
//     G.printgraph();
//     // G.kruskal();
//     // G.prim();
//     G.dijkstra(0, 3);
// }