#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<map>
#include<algorithm>
#include<iterator>

#include "GraphAdjList.h"
using namespace std;

int main(int argc, char *argv[])
{
  ifstream ifile(argv[2]);
  ofstream ofile(argv[4], ios::out);
  int N;

  //cout << argv[1] << " " << N << endl;
  ifile >> N;
  GraphAdjList G(N);
  
  int src, dest, weight;
// cout << "dfj" << endl;
  while (ifile >> src >> dest >> weight)
    {
      G.addedge(src, dest, weight);
      // Make sure that bidirectional edges are added.
    }
      // cout << "Fr" << endl;

  // Change this to long option
  string s(argv[6]);
  cout << "Fr" << endl;
  if (s == "prim"){
    G.prim(ofile);
  }else{
    G.kruskal(ofile);
  }
}
