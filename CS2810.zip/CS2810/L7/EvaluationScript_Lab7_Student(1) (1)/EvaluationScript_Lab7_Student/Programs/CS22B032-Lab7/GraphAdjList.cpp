#include "GraphAdjList.h"

GraphAdjList::GraphAdjList(int nc, int ec) : Graph(nc, ec)
{
    AdjList.resize(nc);
    indegree.resize(nc);
}

void GraphAdjList ::addedge(int src, int dest, int weight)
{   
    int V = getnodecount();
    if(src >= V || dest >= V || src < 0 || dest <0)return;
    if (src == dest)
        return; // if simple graph
    auto [it, success] = AdjList[src].insert(make_pair(dest, weight));
    auto [it2, success2] = AdjList[dest].insert(make_pair(src, weight));
    if (success)
        indegree[src]++;
    if (success2)
        indegree[dest]++;
    if (success && success2)
        setedgecount(getedgecount() + 1);
    // cout << "Adding edge " << "( " << src <<" ," << dest <<" )  with weight "<< weight << endl;
}

// void kruskal(ofstream &ofile);

// void prim(ofstream &ofile);

void GraphAdjList ::printgraph()
{

    cout << "Node : " << getnodecount() << " and Edges : " << getedgecount() << endl;
    for (int i = 0; i < AdjList.size(); i++)
    {
        cout << "Node : " << i << "| " << "has degree " << indegree[i] << " ";
        for (auto items : AdjList[i])
            cout << "(" << items.first << ", " << items.second << ") ";
        cout << endl;
    }
}

void GraphAdjList ::deledge(int src, int dest)
{   
    int V = getnodecount();
    if(src >= V && dest >= V && src < 0 && dest <0)return;
    auto it = AdjList[src].find(dest);
    auto it1 = AdjList[dest].find(src);
    if (it != AdjList[src].end())
    {
        AdjList[src].erase(dest);
        indegree[src]--;
    }
    if (it1 != AdjList[dest].end())
    {
        AdjList[dest].erase(src);
        indegree[dest]--;
        setedgecount(getedgecount() - 1);
    }
}

// std::priority_queue<int> pq; -> for maxheap
// priority_queue <int, vector<int>, greater<int>> gq; -> for minheap

void GraphAdjList ::kruskal(ofstream &ofile)
{
    int V = getnodecount();
    int E = getedgecount();
    vector<set<int>> sets(V);
    for (int i = 0; i < V; i++)
    {
        sets[i].insert(i);
    }
    priority_queue<ipair, vector<ipair>, greater<ipair>> EdgePQ;
    for (int i = 0; i < V; i++)
    {
        int src = i;
        for (auto Edg : AdjList[i])
        {
            int dest = Edg.first;
            int wt = Edg.second;
            EdgePQ.push(make_pair(wt, make_pair(src, dest)));
        }
    }
    // set<int> mst;
    int min_wt = 0;
    bool flag = false;
    while (!EdgePQ.empty())
    {
        auto min_edg = EdgePQ.top();
        EdgePQ.pop();

        int src = min_edg.second.first;
        int dest = min_edg.second.second;
        int wgt = min_edg.first;

        set<int> *set_a = nullptr;
        set<int> *set_b = nullptr;

        for (auto &set_i : sets)
        {
            // if(set_i.size() == V) flag = true;
            if (set_i.find(src) != set_i.end())
                set_a = &set_i;
            if (set_i.find(dest) != set_i.end())
                set_b = &set_i;
        }
        if (flag)
            break;
        if ((set_a != nullptr && set_b != nullptr) && set_a != set_b)
        {
            set_a->insert(set_b->begin(), set_b->end());
            min_wt += wgt;
            set_b->clear();
            ofile << src << " " << dest << " " << wgt << endl;
        }
    }
    ofile << min_wt << endl;
}

void GraphAdjList::prim(ofstream &ofile)
{
    int V = getnodecount();
    int E = getedgecount();
    set<int> mst;
    mst.insert(0);
    priority_queue<ipair, vector<ipair>, greater<ipair>> EdgePQ;
    int src = 0;
    if(V == 0){
        ofile << 0 << endl;
        return;
    }
 

    for (auto Edg : AdjList[src])
    {
        int dest = Edg.first;
        int wt = Edg.second;
        EdgePQ.push(make_pair(wt, make_pair(src, dest)));
    }

    cout << "rfgv" << endl;
    int min_wt = 0;
    while (mst.size() != V)
    {
        auto min_edg = EdgePQ.top();
        EdgePQ.pop();
        src = min_edg.second.first;
        int dest = min_edg.second.second;
        int wt = min_edg.first;
        if (mst.find(dest) == mst.end())
        {
            min_wt += wt;
            mst.insert(dest);
            ofile << src << " " << dest << " " << wt << endl;
            for (auto to_add : AdjList[dest])
            {
                int check_wt = to_add.second;
                EdgePQ.push(make_pair(check_wt, make_pair(dest, to_add.first)));
            }
        }
    }
    ofile << min_wt << endl;
}

// int main()
// {
//     GraphAdjList G(5);

//     G.addedge(0, 1, 2);
//     G.addedge(0, 2, 5);
//     G.addedge(0, 3, 7);
//     G.addedge(0, 4, 1);
//     G.addedge(0, 4, 1);
//     G.addedge(1, 1, 1);
//     G.addedge(1, 2, 3);
//     G.addedge(1, 3, 4);
//     G.addedge(2, 4, 7);
//     G.addedge(3, 4, 8);
//     G.addedge(2, 3, 10);
//     G.addedge(4, 1, 9);
//     G.deledge(2, 3);
//     G.deledge(1, 4);
//     G.printgraph();
//     G.kruskal();
//     G.prim();
// }