#include<iostream>
#include<vector> 
using namespace std;
#define ipair pair<int, pair<int, int>>

#pragma once
class Graph
{
 private:
  int nodes;
  int edges;

 public:

  Graph(int nc = 0, int ec = 0)
    {
      nodes = nc;
      edges = ec;
    }

  void setnodecount(int nodecount);
  int getnodecount();

  void setedgecount(int edgecount);
  int getedgecount();

  virtual void addedge(int src, int dest, int weight) = 0;
  // virtual void deledge(int src, int dest) = 0;
  // virtual void printgraph() = 0;

  // virtual void kruskal(ofstream &ofile) = 0;
  // virtual void prim (ofstream &ofile) = 0;

};
