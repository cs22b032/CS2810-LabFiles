#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<map>
#include<algorithm>
#include<iterator>

#include "GraphAdjList.h"
using namespace std;

int main(int argc, char *argv[])
{
  ifstream ifile(argv[1]);
  ofstream ofile(argv[2], ios::out);
  int N;

  //cout << argv[1] << " " << N << endl;

  ifile >> N;
  GraphAdjList G(N);
  
  int src, dest, weight;

  while (ifile >> src >> dest >> weight)
    {
      G.addedge(src, dest, weight);
      // Make sure that bidirectional edges are added.
    }

  // Change this to long option
  if (stoi(argv[3]) == 1)
    G.kruskal(ofile);
  if (stoi(argv[3]) == 2)
    G.prim(ofile);
}
