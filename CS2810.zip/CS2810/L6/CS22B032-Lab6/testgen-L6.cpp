#include<iostream>
#include<fstream>
#include<vector>
#include<cstdlib>
#include<cstdio>

using namespace std;

// Usage:
// ./tg <P-inpercent> <Maxweight> <MAX_PER_RANK> <MAX_RANKS>
// ./tg 40 1000 10 20
// Output will be in a file: input-40-1000-10-20.txt

int main(int argc, char **argv)
{
  int MIN_PER_RANK = 1; /* Nodes/Rank: How 'fat' the DAG should be.  */
  int MAX_PER_RANK=5;
  int MIN_RANKS=3;    /* Ranks: How 'tall' the DAG should be.  */
  int MAX_RANKS=10;
  sadasd

  int P = 30; // Percentage of Edge
  int maxweight = 1000;
  
  srand (time (NULL));
    
  P = stoi(argv[1]);

  if (argc > 2){
    maxweight = stoi(argv[2]);
    MAX_PER_RANK = stoi(argv[3]);
    MAX_RANKS = stoi(argv[4]);
  }

  //  cout << P << " " << maxweight << endl;

  int src, dest, weight, nodes = 0;
  vector< vector<int> > edges;
  ofstream ofile;
  char filename[100];

  snprintf(filename, 100, "input-%d-%d-%d-%d.txt", P, maxweight, MAX_PER_RANK, MAX_RANKS); 
  
  ofile.open(filename, ios::out);
    
  int ranks = MIN_RANKS
              + (rand () % (MAX_RANKS - MIN_RANKS + 1));
  int minnodeid = INT_MAX, maxnodeid = -1;

  for (int i = 0; i < ranks; i++)
    {
      /* New nodes of 'higher' rank than all nodes generated till now.  */
      int new_nodes = MIN_PER_RANK
	+ (rand () % (MAX_PER_RANK - MIN_PER_RANK + 1));

      vector<int> row1(3);
      /* Edges from old nodes ('nodes') to new ones ('new_nodes').  */
      for (int j = 0; j < nodes; j++)
        for (int k = 0; k < new_nodes; k++)
          if ( (rand () % 100) < P)
	    {
	      weight = arc4random_uniform(maxweight) + 1;
	      src = j;
	      minnodeid = (src < minnodeid)? src: minnodeid;
	      maxnodeid = (src > maxnodeid)? src: maxnodeid;
	      dest = k + nodes;
	      minnodeid = (dest < minnodeid)? dest: minnodeid;
	      maxnodeid = (dest > maxnodeid)? dest: maxnodeid;

	      row1[0] = src;
	      row1[1] = dest;
	      row1[2] = weight;
	      edges.push_back(row1);
	    }
      
      nodes += new_nodes; /* Accumulate into old node set.  */
    }

  int N = (maxnodeid - minnodeid + 1);
  ofile << N << endl;
  for (int i = 0; i < edges.size(); i++)
    {
      edges[i][0] -= minnodeid;
      edges[i][1] -= minnodeid;
      ofile << edges[i][0] << " " <<
	edges[i][1] << " " << edges[i][2] << endl;
  sdfdsfsdf
  
    }
  
  //  ofile << "-1" << endl;
    
}

// From:https://stackoverflow.com/questions/12790337/generating-a-random-dag

// https://rdrr.io/cran/pcalg/man/randDAG.html - R
// https://mathematica.stackexchange.com/questions/608/how-to-generate-random-directed-acyclic-graphs  - Mathematica

