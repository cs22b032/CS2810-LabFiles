//  Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 06
// Date: 12/03, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include "Graph.h"


// int nodes;
// int edges;

void Graph :: setnodecount(int nodecount)
{
    nodes = nodecount;
}

int Graph :: getnodecount()
{
    return nodes;
}

void Graph :: setedgecount(int edgecount)
{
    edges = edgecount;
}

int Graph :: getedgecount()
{
    return edges;
}

void Graph:: incED(){
    edges++;
}


void Graph:: deced(){
    edges--;
}