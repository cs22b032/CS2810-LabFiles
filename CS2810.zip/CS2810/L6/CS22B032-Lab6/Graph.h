//  Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 06
// Date: 12/03, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include<iostream>
#include<vector> 
using namespace std;
// Node indices go from 0 to nodes-1
// Edge indices go from 0 to edges-1
// Edge weights are integer values

#pragma once
class Graph
{
 private:
  int nodes;
  int edges;

 public:

  Graph(int nc = 0, int ec = 0)
    {
      nodes = nc;
      edges = ec;
    }

  void setnodecount(int nodecount);
  int getnodecount();
  void deced();
  void setedgecount(int edgecount);
  int getedgecount();
  void incED();
  virtual void addedge(int src, int dest, int weight) = 0;
  virtual void deledge(int src, int dest) = 0;
  virtual vector<int> toposort() = 0;
  virtual void printgraph() = 0;

};
