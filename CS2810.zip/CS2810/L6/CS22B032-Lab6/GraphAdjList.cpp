#include "GraphAdjList.h"

// vector< map<int, int, less <int> > > AdjList;
// vector<int> indegree;	// Initialized to zero

GraphAdjList :: GraphAdjList(int nc, int ec) : Graph(nc, ec)
{
  // Hint: resize() method of vector() can be invoked to create a vector
  // of required size. This will help avoid seg. faults
  AdjList.resize(nc);
  indegree.resize(nc,0);
}


void GraphAdjList::printgraph()
{
  int N = getnodecount();
  int E = getedgecount();

  cout << N << " " << E << endl;
  for (int node = 0; node < N; node++)
    {
      for (auto ptr = AdjList[node].begin();
	   ptr != AdjList[node].end();
	   ptr++)
	{
	  cout << node << " " << ptr->first << " " << ptr->second << endl;
	}
    }
}

// Please verify if this code is correct, before proceeding.
// This validates if a given TS output is valid (meeting the edge
// constraints of the graph).  
bool GraphAdjList::validateTS(vector<int> TS)
{
  int nid1, nid2;
  
  for (int i = 0; i < TS.size(); i++)
    {
      nid1 = TS[i];

      for (int j = i; j < TS.size(); j++)
	{
	  nid2 = TS[j];
	  if (AdjList[nid2].find(nid1) != AdjList[nid2].end())
	    return false;
	}
    }

  return true;
  
}

void GraphAdjList  :: addedge(int src, int dest, int weight)
{
  AdjList[src][dest] = weight;
  indegree[dest] ++;
  // cout << "src = " << src << "\n";
  // for (auto i : AdjList[src]){
  //   cout << "i = " << i.first << " ";
  // }
  // cout << endl;
  // incED();
}

void GraphAdjList ::  deledge(int src, int dest)
{
  auto todelete = AdjList[src].find(dest);
  if(todelete != AdjList[src].end())
  {
    AdjList[src].erase(dest);
    // indegree[src]++;
    // indegree[dest]--;
    // deced();
  }
  //else cout << "NOt found" << endl;
}

vector<int> GraphAdjList ::  toposort()
{
  vector<int> topo;
  queue <int> q;
  for(int i = 0; i < indegree.size() ;i++){
    if(indegree[i] == 0)
    {
      q.push(i);
    }

  }
  while(!q.empty())
  {
    int r = q.front();
    q.pop();
    topo.push_back(r);

    for ( auto mapItem : AdjList[r] )
    {

      int s = mapItem.first;
      indegree[s]-=1;
      if(indegree[s] == 0) {
        q.push(s);
      }
    }
   
  }
  return topo;
}
