#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<map>
#include<algorithm>
#include<iterator>

#include "GraphAdjList.h"
using namespace std;

int main(int argc, char *argv[])
{
  ifstream ifile(argv[1]);
  ofstream ofile(argv[2]);
  int N;
  ifile >> N;
  int a, b, c;
  GraphAdjList G(N);
    while (N--)
    {
       ifile >> a >> b >> c ;
       G.addedge(a, b, c);
    }


  vector<int> TS;
      // G.printgraph();
  TS = G.toposort();

  // Uncomment this for testing purposes ONLY; Comment it before submission.
  //  bool valid = G.validateTS(TS);
  //  cout << "Topo Sort is Correct? " << valid << endl;
   for(auto it : TS){
    ofile << it << " ";
   }
   ofile << endl;
}
