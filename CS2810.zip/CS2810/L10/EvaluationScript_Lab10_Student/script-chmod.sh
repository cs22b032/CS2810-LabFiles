chmod -c +x clean.sh
chmod -c +x script-mk-stud.sh
chmod -c 0444 testcases/Q1/*.txt
chmod -c 0444 expected_outputs/Q1/*.txt