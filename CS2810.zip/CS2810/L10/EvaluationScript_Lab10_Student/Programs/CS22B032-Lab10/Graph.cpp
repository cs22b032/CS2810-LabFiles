// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 10
// Date: 23/04, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include "Graph.h"

void Graph ::setnodecount(int nodecount)
{
    nodes = nodecount;
}

int Graph ::getnodecount()
{
    return nodes;
}

void Graph ::setedgecount(int edgecount)
{
    edges = edgecount;
}

int Graph ::getedgecount()
{
    return edges;
}