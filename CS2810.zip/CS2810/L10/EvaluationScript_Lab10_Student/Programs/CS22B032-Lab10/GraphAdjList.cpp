#include "GraphAdjList.h"

GraphAdjList::GraphAdjList(int nc, int ec) : Graph(nc, ec)
{
  AdjList.resize(nc);
  degree.resize(nc);
}

void GraphAdjList ::addedge(int src, int dest, int weight)
{
  int V = getnodecount();
  if (src >= V || dest >= V || src < 0 || dest < 0)
    return;
  if (src == dest)
    return; // if simple graph
  auto [it, success] = AdjList[src].insert(make_pair(dest, weight));
  auto [it2, success2] = AdjList[dest].insert(make_pair(src, weight));
  if (success)
    degree[src]++;
  if (success2)
    degree[dest]++;
  if (success && success2)
    setedgecount(getedgecount() + 1);
  // cout << "Adding edge " << "( " << src <<" ," << dest <<" )  with weight "<< weight << endl;
}

void GraphAdjList ::deledge(int src, int dest)
{
  int V = getnodecount();
  if (src >= V && dest >= V && src < 0 && dest < 0)
    return;
  auto it = AdjList[src].find(dest);
  auto it1 = AdjList[dest].find(src);
  if (it != AdjList[src].end())
  {
    AdjList[src].erase(dest);
    degree[src]--;
  }
  if (it1 != AdjList[dest].end())
  {
    AdjList[dest].erase(src);
    degree[dest]--;
    setedgecount(getedgecount() - 1);
  }
  
}

void printset(set<int> &S)
{
  cout << "*** \t Printing set with size k: " << S.size() << endl;
  for (auto ptr = S.begin(); ptr != S.end(); ptr++)
    cout << *ptr << " ";
  cout << "\n***\n"
       << endl;
}

void GraphAdjList::printgraph()
{
  int N = getnodecount();
  int E = getedgecount();

  cout << "\n** Printing graph **\n";

  cout << N << " " << E << endl;
  for (int node = 0; node < N; node++)
  {
    cout << "Degree of " << node << " is: " << degree[node] << endl;
    for (auto ptr = AdjList[node].begin(); ptr != AdjList[node].end(); ptr++)
    {
      cout << node << " " << ptr->first << " " << ptr->second << endl;
    }
  }

  cout << "\n** Printed graph **\n";
}

set<int> GraphAdjList::vcover_greedy()
{
  int N = getnodecount();
  set<int> vcoverset;
  vcoverset = {};
  GraphAdjList Gnew(*this);
  if (N == 0)
    return vcoverset;
  else if (N == 1)
  {
    int first_node = 0;
    vcoverset.insert(first_node); // check this line
    return vcoverset;
  }
  int u = 0;
  while (Gnew.getedgecount() != 0 && u < N)
  {
    if (Gnew.degree[u] == 0) { u++; continue;};
    int v = (*Gnew.AdjList[u].begin()).first;
    vcoverset.insert(u);
    vcoverset.insert(v);
    for (auto ptr = AdjList[u].begin(); ptr != AdjList[u].end(); ptr++)
    {
      Gnew.deledge(u, ptr->first);
    }
    for (auto ptr = AdjList[v].begin(); ptr != AdjList[v].end(); ptr++)
    {
      Gnew.deledge(v, ptr->first);
    }
    u++;
  }
  // Gnew.printgraph();
  return vcoverset;
}

// Create all subsets
// Go through each subset and cover all edges of nodes in this subset in the graph.
// if edgecount goes to the number of edges in the graph, then check if it is minimum sized
// return the minimum set
set<int> GraphAdjList::vcover_expon()
{
  int k, N;
  N = getnodecount();
  k = N + 1;
  set<int> vcoverset;
  vcoverset = {};
  GraphAdjList G2(*this);
  if (N == 0)
    return vcoverset;
  else if (N == 1)
  {
    // int first_node =
        //  vcoverset.insert(Grap); // check this line
    return vcoverset;
  }


  return vcoverset;
}

// int main()
// {
//   GraphAdjList G(6);

//   G.addedge(0, 1, 1);
//   G.addedge(0, 2, 2);
//   G.addedge(1, 3, 3);
//   G.addedge(1, 4, 4);
//   G.addedge(2, 3, 7);
//   G.addedge(3, 5, 6);
//   G.addedge(4, 5, 5);
//   //     G.addedge(1, 3, 4);
//   //     G.addedge(2, 4, 7);
//   //     G.addedge(3, 4, 8);
//   //     G.addedge(2, 3, 10);
//   //     G.addedge(4, 1, 9);
//   //     G.deledge(2, 3);
//   //     G.deledge(1, 4);
//   G.printgraph();
//   set<int> S = G.vcover_greedy();

//   //     // G.kruskal();
//   //     // G.prim();
//   //     // G.dijkstra(0, 3);
//     for (auto ptr = S.begin(); ptr != S.end(); ptr++)
//       cout << *ptr << " ";
//     cout << endl;
// }

// 6
// 2 0 1 1
// 3 0 2 2
// 4 1 3 3
// 5 1 4 4
// 6 2 3 7
// 7 3 5 6
// 8 4 5 5