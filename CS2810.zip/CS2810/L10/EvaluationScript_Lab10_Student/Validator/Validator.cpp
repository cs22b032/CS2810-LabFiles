#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<map>
#include<stack>
#include<algorithm>
#include<iterator>
#include<cassert>
#include <stdlib.h>
#include <getopt.h>
#include "GraphAdjList.h"
using namespace std;

// You MUST add the long options code from the earlier example.

int main(int argc, char *argv[])
{
  ifstream ifile;
  ifstream ofile;
  int N, k;

  static struct option long_options[] =
  {
    /* These options don’t set a flag.
       We distinguish them by their indices. */
    {"in",  required_argument, 0, 'i'},
    {"out",  required_argument, 0, 'o'},
    {"vc",  required_argument, 0, 'v'},
    {0, 0, 0, 0}
  };

  while (1)
  {
    /* getopt_long stores the option index here. */
    int option_index = 0;
    int id;

    id = getopt_long (argc, argv, "i:o:v:", long_options, &option_index);

    /* Detect the end of the options. */
    if (id == -1)
      break;

    switch (id)
    {
    case 'i':
      ifile.open(optarg, ios::in);
      break;

    case 'o':
      ofile.open(optarg, ios::in);
      break;

    case 'v':
      k = atoi(optarg);
      break;

    case '?':
      /* getopt_long already printed an error message. */
      abort();
      break;

    default:
      abort ();
    }
  }

  ifile >> N;
  GraphAdjList G(N);
  
  int src, dest, weight;
  
  while (ifile >> src >> dest >> weight)
  {
    G.addedge(src, dest, weight);
    // Make sure that bidirectional edges are added.
  }

  set<int> S;
  int u;
  int prev = -1;
  while (ofile >> u)
  {
    if (u >= 0 && u < N && u > prev)
    {
      prev = u;
      S.insert(u);
    }
    else
    {
      S.clear();
      break;
    }
  }

  if (S.size() == k)
    cout << G.verifyVC(S) << endl;
  else
    cout << false << endl;
}
