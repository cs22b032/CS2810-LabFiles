#include "GraphAdjList.h"

GraphAdjList::GraphAdjList(int nc, int ec): Graph(nc, ec)
{
  if (nc > 0) {
    AdjList.resize(nc);
  }
  degree.resize(nc);
  for (int i = 0; i < nc; i++)
    degree[i] = 0;
}

void GraphAdjList::addedge(int s, int d, int w)
{
  pair <map<int, int>::iterator, bool> ptr;
  // cout << "In GAL AddEdge " << indegree.size()
  //     << " " << s << " " << d << " " << w << endl;

  // Bidirectional edge - Count edge once in each direction
  ptr = AdjList[s].insert(make_pair( d, w ));
  setedgecount(getedgecount()+1);
  degree[s]++;
  
  ptr = AdjList[d].insert(make_pair( s, w ));
  setedgecount(getedgecount()+1);
  degree[d]++;
  //  cout << "\tEdge #: " << getedgecount() << endl;
}

void GraphAdjList::deledge(int s, int d)
{

  // cout << "Initial neighbors of " << s << ": ";
    
  // for (auto nptr = AdjList[s].begin();
  //      nptr != AdjList[s].end();  nptr++)
  //   {
  //     cout << nptr->first << " ";
  //   }

  // cout << endl;

  // cout << "Erasing an edge " << s << " " << d << endl;

  AdjList[s].erase(d);
  setedgecount(getedgecount()-1);
  degree[s]--;
  
  // for (auto nptr = AdjList[s].begin();
  //      nptr != AdjList[s].end();  nptr++)
  //   {
  //     cout << nptr->first << " ";
  //   }

  // cout << endl;

  // cout << "Initial neighbors of " << d << ": ";;
  
  // for (auto nptr = AdjList[d].begin();
  //      nptr != AdjList[d].end();  nptr++)
  //   {
  //     cout << nptr->first << " ";
  //   }

  // cout << endl;
    
  // cout << "Erasing an edge " << d << " " << s << endl;

  AdjList[d].erase(s);
  setedgecount(getedgecount()-1);
  degree[d]--;
  
  // for (auto nptr = AdjList[d].begin();
  //      nptr != AdjList[d].end();  nptr++)
  //   {
  //     cout << nptr->first << " ";
  //   }

  // cout << endl;

  // cout << "Done deleting edge " << s << " " << d << endl;

}

bool GraphAdjList::verifyVC(set<int> S)
{
  bool result = false;
  int N = getnodecount();
  int edgesCovered = 0;
  int E = getedgecount();

  vector< map<int, bool, less <int> > > VisitedEdge(N);
  for (int i = 0; i < N; i++)
  {
    for (auto ptr = AdjList[i].begin(); ptr != AdjList[i].end(); ptr++)
    {
      VisitedEdge[i].insert(make_pair(ptr->first, false));
    }
  }

  // cout << E << endl;

  for (auto ptr = S.begin(); ptr != S.end(); ptr++)
  {
    int curnode = *ptr;

    if (curnode < 0 || curnode >= N)
      break;

    for (auto ptr2 = AdjList[curnode].begin(); ptr2 != AdjList[curnode].end();  ptr2++)
    {
      int v = ptr2->first;

      if ( !VisitedEdge[curnode][v] )
      {
        VisitedEdge[curnode][v] = true;
        edgesCovered++;
      }

      if ( !VisitedEdge[v][curnode] )
      {
        VisitedEdge[v][curnode] = true;
        edgesCovered++;
      }
    }
  }

  // cout << edgesCovered << endl;

  if ( edgesCovered == E )
    result = true;
  
  return result;
}
