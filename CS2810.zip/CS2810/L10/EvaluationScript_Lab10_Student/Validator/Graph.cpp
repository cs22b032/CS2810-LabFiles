#include "Graph.h"

void Graph::setnodecount(int nodecount)
{
  nodes = nodecount;
}

int Graph::getnodecount()
{
  return nodes;
}

void Graph::setedgecount(int edgecount)
{
  edges = edgecount;
}

int Graph::getedgecount()
{
  return edges;
}