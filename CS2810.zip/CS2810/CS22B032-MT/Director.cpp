// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate

// Actor / Director: The Actor class has the following additional private data elements: (i) int filmsacted; (ii)
// int hitfilms.
// The Director class has the following additional private data elements: (i) int filmsdirected
#include <iostream>
#include <string>
#include <vector>
using namespace std;
#include "Director.h"

Director ::Director() : Artiste()
{
    filmsdirected = 0;
}

Director::Director(int id1 , string fname1, string lname1, int s1 ,int fd)
    : Artiste(id1, fname1, lname1, s1)
{
    filmsdirected = fd;
}

int Director ::getFilmsDir()
{
    return filmsdirected;
}

void Director :: display()
{
    cout << this->getId() << " " <<  this->getFName() << " " << this->getLName() << " "<< this->getSalary() << " "<< this->filmsdirected <<  endl;
    //actor 0 Sharleen Naval 1645 879 518
}