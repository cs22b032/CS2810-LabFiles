// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include <string>
#include <vector>
using namespace std;

#pragma once
// enum type
// {
//   director, actor , none
// };

class Artiste
{

private:
  int id;
  string fname;
  string lname;
  int salary;
  // type tp;
  // static const int NUM = 3;
  // const string Names[NUM] = {"director", "actor", "none"};

public:
  Artiste();
  Artiste(int id1, string fname1, string lname1, int s1);
  // // default is -1, "", "", -1
  // {
  //   id = id1;
  //   fname = fname1;
  //   lname = lname1;
  //   salary = s1;
  //   tp = none;
  // }

  string getFName();
  string getLName();
  int getId();
  int getSalary();
  void setSalary(int s1);
  virtual void display() = 0;
};
