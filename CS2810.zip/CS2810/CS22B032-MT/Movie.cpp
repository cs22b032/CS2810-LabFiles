#include "Movie.h"

Movie :: Movie(Director *d1, vector<Actor *> A1, int m1 , string mname1 ,
    int va ){
        diro = d1;
        ActorList = A1;
        vasool = va;
        mid = m1;
        mname = mname1;

        cost = diro->getSalary();

        int sum = 0;
        for(auto it : ActorList){
            sum += it->getSalary();
        }
        cost += sum;
        profit = vasool - cost;
    }