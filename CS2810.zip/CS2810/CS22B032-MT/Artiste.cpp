// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate

// private:
// int id;
// string fname;
// string lname;
// int salary;
// public:
#include "Artiste.h"

Artiste ::Artiste()
{
    id = -1;
    fname = "";
    lname = "";
    salary = -1;
}

Artiste ::Artiste(int id1, string fname1, string lname1, int s1)
// default is -1, "", "", -1
{
    id = id1;
    fname = fname1;
    lname = lname1;
    salary = s1;
    //tp = tp1;
}

string Artiste ::getFName()
{
    return fname;
}

string Artiste ::getLName()
{
    return lname;
}

int Artiste ::getId()
{
    return id;
}

int Artiste ::getSalary()
{
    return salary;
}

void Artiste ::setSalary(int s1)
{
    salary = s1;
}