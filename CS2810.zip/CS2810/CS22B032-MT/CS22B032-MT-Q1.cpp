// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include "Actor.h"
#include "Artiste.h"
#include "Director.h"
#include "Movie.h"
using namespace std;

int main()
{
    // MAKE VECTORS FOR ACTORS DIRECTORS AND MOVIES
    vector<Artiste *> AllActors;
    vector<Artiste *> AllDirectors;
    vector<Movie *> AllMovies;
    // TEMPORORY STRING
    string s;
    cin >> s;
    // FOR ACTOR ID
    int aid = 0;
    // FOR DIRECTOR ID
    int did = 0;
    while (s != "END")
    {
        // IF ACTOR
        if (s == "actor")
        {
            // SOME TEMPORY VARIABLES
            string fn, ln;
            int sal;
            int nac;
            int nhits;
            cin >> fn >> ln >> sal >> nac >> nhits;
            // PUSH INTO ALL ACTORS BY MAKING CONSTRUCTOR FROM GIVEN DATAS
            AllActors.push_back((Actor *)new Actor(aid, fn, ln, sal, nac, nhits));
            // INCRESE COUNTER ID
            aid++;
        }
        // IF DIRECTOR
        else if (s == "director")
        {
            // TAKING SOME TEMP VARIABLES
            string fn, ln;
            int sal;
            int ndirec;
            cin >> fn >> ln >> sal >> ndirec;
            // PUSH INTO ALL DIRECTORS BY MAKING CONSTRUCTOR FROM GIVEN DATAS
            AllDirectors.push_back((Director *)new Director(did, fn, ln, sal, ndirec));
            did++;
        }
        cin >> s;
    }

    s = "";
    cin >> s;
    int mid = 0;
    // mname dirid vasool N actorid1 actorid2 ... actoridN
    while (s != "END")
    {
        // TAKING INPUTS AS GIVEN
        int dirid, vasool, N;
        cin >> dirid >> vasool >> N;
        // act_worked -> WHO WORKED IN MOVIES
        vector<Actor *> act_worked;
        for (int i = 0; i < N; i++)
        {
            int acti;
            cin >> acti;
            act_worked.push_back((Actor *)AllActors[acti]);
        }
        // FINDING DIRECTOR WITH GIVEN ID
        Director *dire = (Director *)AllDirectors[dirid];
        // PUSHING IN ALLMOVIES VECTOR
        AllMovies.push_back((Movie *)new Movie(dire, act_worked, mid, s, vasool));
        // INCREASING COUNTER
        mid++;
        // TAKING MOVIE NAME AGAIN
        cin >> s;
    }
    //FOR QUERIES
    char q;
    cin >> q;
    while (q != 'X')
    {
        if (q == 'A')
        {
            //PRINT WITH HITS >= X
            int x;
            cin >> x;
            for (auto ac : AllActors)
            {
                auto actr = (Actor *)ac;
                if (actr->getHits() >= x)
                    cout << actr->getFName() << " " << actr->getLName() << endl;
            }
        }
        else if (q == 'C')
        {
            //DISPLAYING ACTOR WITH ID GIVEN
            int iid;
            cin >> iid;
            if (iid < AllActors.size())
            {
                cout << "actor ";
                auto actr = (Actor *)AllActors[iid];
                actr->display();
            }
        }
        else if (q == 'D')
        {
            //DISPLAYING DIRECTOR WITH GIVEN ID
            int iid;
            cin >> iid;
            if (iid < AllDirectors.size())
            {
                cout << "director ";
                auto dicr = (Director *)AllDirectors[iid];
                dicr->display();
            }
        }
        else if (q == 'M')
        {
            //DISPLAYING MOVIE WITH MAXIMUM PROFIT
            int max_profit = 0;
            Movie *max_m = nullptr;
            for (auto mov : AllMovies)
            {
                if (mov->getProfit() > max_profit)
                {
                    max_profit = mov->getProfit();
                    max_m = mov;
                }
            }
            if (max_m != nullptr)
                max_m->printprofit();
        }
        // TAKE AGAIN QUERY
        cin >> q;
    }
}