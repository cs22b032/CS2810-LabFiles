// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate

// Actor / Director: The Actor class has the following additional private data elements: (i) int filmsacted; (ii)
// int hitfilms.
// The Director class has the following additional private data elements: (i) int filmsdirected

#include "Actor.h"

Actor ::Actor() : Artiste()
{
    filmsacted = 0;
    hitfilms = 0;
}
Actor ::Actor(int id1, string fname1, string lname1, int s1, int fs, int hf)
    : Artiste(id1, fname1, lname1, s1)
{
    filmsacted = fs;
    hitfilms = hf;
}

int Actor ::getFilmsac()
{
    return filmsacted;
}

int Actor ::getHits()
{
    return hitfilms;
}

void Actor ::display()
{
    cout << this->getId() << " " <<  this->getFName() << " " << this->getLName() << " "<< this->getSalary() << " "<< this->getFilmsac()
    << " " << this->getHits() <<  endl;
    //actor 0 Sharleen Naval 1645 879 518
}