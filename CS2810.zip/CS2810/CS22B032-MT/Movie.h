// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include <string>
#include <vector>

#include "Artiste.h"
#include "Actor.h"
#include "Director.h"

#pragma once
class Movie
{

private:
  int mid;
  string mname; // No Spaces; only from [A-Z][a-z]
  Director *diro;
  vector<Actor *> ActorList;
  int vasool; // Collection from theatres, OTT, etc.

  // Computed
  int cost;   // Salary of Director + Salary of Actors
  int profit; // vasool - cost

public:
  Movie()
  {
    mid = -1;
    diro = nullptr;
    mname = "";
    vasool = -1;
  }

  // Non-default arguments at start
  Movie(Director *d1, vector<Actor *> A1, int m1 = -1, string mname1 = "",
        int va = -1);

  int getProfit()
  {
    return profit;
  }

  void printprofit()
  {
    cout << "Movie: " << mname << "; Profit: " << profit << endl;
  }

  void display();
  // Define suitable public member functions based on queries / virtual
  // functions etc.
};
