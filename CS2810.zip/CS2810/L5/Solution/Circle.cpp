#include "Circle.h"

// For circle, side = radius

Circle::Circle(int id1, stype sht1, unsigned int r, string col):
  Shape(id1, sht1), Color(col)
{
  side = r;
}
  
double Circle::area()
{
  return (M_PI*side*side);
}

double Circle::perimeter()
{
  return (2.0*M_PI*side);
}

// For circle, diagonal = diameter

double Circle::diagonal()
{
  return (2.0*side);
}
