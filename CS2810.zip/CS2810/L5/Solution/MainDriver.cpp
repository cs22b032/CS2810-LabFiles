#include "Shape.h"
#include "Triangle.h"
#include "Color.h"
#include "Square.h"
#include "Hexagon.h"
#include "Circle.h"

using namespace std;

// Modify this to print color value *AFTER* Shape string if
// the Shape is a Circle.

void display(Shape *s)
{
  cout << "Id: " << s->getId() <<
    " Shape: " << s->getShapeName();
    // " Color: " << ... <<
    if (s->getType() == circle) cout << " Color: " << ((Circle *) s)->getColor();

    cout << " Area: " << (int) s->area() <<
    " Perimeter: " << (int) s->perimeter() <<
    " Diagonal: " << (int) s->diagonal() << endl;
}

// Returns type of shape (stype) for given string

stype getTypeFromString(string str)
{
  stype ans;

  if (str == "triangle")
  {
    ans = triangle;
  }
  else if (str == "square")
  {
    ans = square;
  }
  else if (str == "hexagon")
  {
    ans = hexagon;
  }
  else if (str == "circle")
  {
    ans = circle;
  }
  else
  {
    ans = none;
  }

  return ans;
}

int main()
{
  vector<Shape *> AllShapes;

  string str1;
  unsigned int id1, side1;

  cin >> str1 >> side1;
  id1 = 0;
  
  while (str1 != "END")
  {
    if (str1 == "triangle")
  	{
  	  AllShapes.push_back(new Triangle(id1, triangle, side1));
  	}
    else if (str1 == "square")
    {
      AllShapes.push_back(new Square(id1, square, side1));
    }
    else if (str1 == "hexagon")
    {
      AllShapes.push_back(new Hexagon(id1, hexagon, side1));
    }
    else if (str1 == "circle")
    {
      AllShapes.push_back(new Circle(id1, circle, side1));
    }
    else
    {
      id1--; // Ignore other shapes, don't increase identifier
    }

    id1++;
    cin >> str1 >> side1;
  }

  // cout << "--------------------------------" << endl;
  // for (int i = 0; i < AllShapes.size(); i++)
  // {
  //   display(AllShapes[i]);
  // }
  // cout << "--------------------------------" << endl;

  string Q;
  cin >> Q;

  while (Q != "X")
  {
    if (Q == "P")
    {
      cin >> id1;
      if (id1 >= AllShapes.size())
      {
        cout << "-1" << endl;
      }
      else
      {
        display(AllShapes[id1]);
      }
    }
    else if (Q == "A")
    {
      cin >> str1;

      double max_area = -1.0;
      unsigned int max_id = 0;
      double area;

      for (int i = 0; i < AllShapes.size(); i++)
      {
        // Shape of type str1
        if (AllShapes[i]->getType() == getTypeFromString(str1))
        {
          area = AllShapes[i]->area();
          if (area > max_area)
          {
            max_area = area;
            max_id = i;
          }
        }
      }

      // No shape instance of str1 type present in AllShapes vector
      if (max_area < 0)
      {
        cout << "-1" << endl;
      }
      else
      {
        display(AllShapes[max_id]);
      }
    }
    else if (Q == "H")
    {
      if (AllShapes.empty())
      {
        cout << "-1" << endl;
      }
      else
      {
        double max_area = -1.0;
        unsigned int max_id = 0;
        double area;

        for (int i = 0; i < AllShapes.size(); i++)
        {
          area = AllShapes[i]->area();
          if (area > max_area)
          {
            max_area = area;
            max_id = i;
          }
        }

        display(AllShapes[max_id]);
      }
    }

    cin >> Q;
  }
  
}
