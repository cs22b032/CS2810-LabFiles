#include "Shape.h"

// Return Id
int Shape::getId()
{
  return id;
}

// Return shape_type
stype Shape::getType()
{
  return shape_type;
}

// Return ShapeName
string Shape::getShapeName()
{
  return ShapeNames[shape_type];
}

  
