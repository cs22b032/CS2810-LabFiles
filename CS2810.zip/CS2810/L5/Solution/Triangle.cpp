#include "Triangle.h"

Triangle::Triangle(int id1, stype sht1, unsigned int s1):
  Shape(id1, sht1)
{
  side = s1;
}
  
double Triangle::area()
{
  return (sqrt(3)*side*side/4.0);
}

double Triangle::perimeter()
{
  return (3.0*side);
}

// For equilateral triangle, diagonal = -1

double Triangle::diagonal()
{
  return (-1.0);
}
