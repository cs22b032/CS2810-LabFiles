#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "Shape.h"

using namespace std;

#pragma once

class Hexagon: public Shape
{
 private:
  unsigned int side;

 public:
  Hexagon(int id1, stype sht1, unsigned int s1 = 0);

  // Must declare the methods here to indicate that
  // the virtual functions in base class will be implemented in this class.
  double area();
  double perimeter();
  double diagonal();
};
// DO NOT INCLUDE any Hexagon.cpp file  etc.
