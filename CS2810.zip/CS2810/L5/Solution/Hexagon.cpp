#include "Hexagon.h"

Hexagon::Hexagon(int id1, stype sht1, unsigned int s1):
  Shape(id1, sht1)
{
  side = s1;
}
  
double Hexagon::area()
{
  return (3.0*sqrt(3)*side*side/2.0);
}

double Hexagon::perimeter()
{
  return (6.0*side);
}

// For hexagon, diagonal = longer diagonal

double Hexagon::diagonal()
{
  return (2.0*side);
}
