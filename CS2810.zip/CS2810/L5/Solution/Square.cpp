#include "Square.h"

Square::Square(int id1, stype sht1, unsigned int s1):
  Shape(id1, sht1)
{
  side = s1;
}
  
double Square::area()
{
  return (1.0*side*side);
}

double Square::perimeter()
{
  return (4.0*side);
}

double Square::diagonal()
{
  return (sqrt(2.0)*side);
}
