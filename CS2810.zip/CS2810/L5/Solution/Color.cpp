#include "Color.h"

Color::Color(string s)
{
  color = s;
}

void Color::setColor(string s)
{
  color = s;
}

string Color::getColor()
{
  return color;
}


