#include "Shape.h"
#include "Color.h"

#pragma once

class Circle:
public Shape, public Color
{
 private:
  unsigned int side;

 public:
  // Complete specifications.
  Circle(int id1, stype sht1, unsigned int r = 0, string col = "none");

  // Must declare the methods here to indicate that
  // the virtual functions in base class will be implemented in this class.
  double area();
  double perimeter();
  double diagonal();
};
// DO NOT INCLUDE any Circle.cpp file  etc.