#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>

using namespace std;

#pragma once
enum stype {triangle, square, hexagon, circle, none};

class Shape
{
 private:
  int id;
  stype shape_type;
  static const int NUMSHAPES = 5;
  const string ShapeNames[NUMSHAPES] =
    {"Triangle", "Square", "Hexagon", "Circle", "None"};  

public:
  
  Shape(int i = -1, stype s = none) {id = i; shape_type = s;}

  // Return Id
  int getId();

  // Return shape_type
  stype getType();

  // Return ShapeName
  string getShapeName();
  
  virtual double area() = 0;
  virtual double perimeter() = 0;
  virtual double diagonal() = 0;

};


