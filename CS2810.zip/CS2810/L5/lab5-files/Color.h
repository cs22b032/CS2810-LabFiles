#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>

using namespace std;

#pragma once

class Color {
 private:
  string color;

 public:

  Color(string s = "none");

  void setColor(string s);
  
  string getColor();
};
