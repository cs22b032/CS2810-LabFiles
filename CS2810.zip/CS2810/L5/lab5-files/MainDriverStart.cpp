#include "Shape.h"
#include "Triangle.h"
// #include "Color.h"
// #include "Square.h"
// #include "Hexagon.h"
// #include "Circle.h"

// Modify this to print color value *AFTER* Shape string if
// the Shape is a Circle.
void display(Shape *s)
{
  cout << "Id: " << s->getId() <<
    " Shape: " << s->getShapeName() <<
    // " Color: " << ... <<
    " Area: " << (int) s->area() <<
    " Perimeter: " << (int) s->perimeter() <<
    " Diagonal: " << (int) s->diagonal() << endl;
}

int main()
{
  vector<Shape *> AllShapes;
  string str1;
  unsigned int id1, side1;
}
