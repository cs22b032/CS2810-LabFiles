// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 05
// Date: 27/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include "Hexagon.h"

Hexagon ::Hexagon(int id1, stype sht1, unsigned int s1 = 0) : Shape(id1, sht1)
{
    this->side = s1;
}

// Must declare the methods here to indicate that
// the virtual functions in base class will be implemented in this class.
double Hexagon ::area()
{
    return ((3 * sqrt(3)) / 2) * (side * side);
}

double Hexagon ::perimeter()
{
    return 6 * side;
}

double Hexagon ::diagonal()
{
    return 2 * side;
}