// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 05
// Date: 27/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.

#include "Shape.h"
#include "Triangle.h"
#include "Color.h"
#include "Square.h"
#include "Hexagon.h"
#include "Circle.h"

// Modified this to print color value *AFTER* Shape string if
// the Shape is a Circle.
void display(Shape *s)
{
    //if not circle then print without typecasting
    if (s->getShapeName() != "Circle")
    {
        cout << "Id: " << s->getId() << " Shape: " << s->getShapeName() <<
            // " Color: " << ... <<
            " Area: " << (int)s->area() << " Perimeter: " << (int)s->perimeter() << " Diagonal: " << (int)s->diagonal() << endl;
    }
    //if circle then typecast it to circle
    else if (s->getShapeName() == "Circle")
    {
        Circle *crc = (Circle *)s;
        cout << "Id: " << crc->getId() << " Shape: " << crc->getShapeName() << " Color: " << crc->getColor() <<

            " Area: " << (int)s->area() << " Perimeter: " << (int)s->perimeter() << " Diagonal: " << (int)s->diagonal() << endl;
    }
}
// Format for printing
// Id: 9 Shape: Circle Color: none Area: 380 Perimeter: 69 Diagonal: 22
int main()
{
    //Allshapes will contain 
    vector<Shape *> AllShapes;
    //tempory string for shape name
    string str1;
    //temporory variable for id and side
    unsigned int id1, side1;
    cin >> str1;
    id1 = 0;
    //id is indexes
    while (str1 != "END")
    {
        cin >> side1;
        //side1 is size of shapes
        if (str1 == "triangle"){
            // calling constructor for triangle
            AllShapes.push_back((Triangle *)new Triangle(id1, triangle, side1));
            id1++;
        }
            
        else if (str1 == "hexagon"){
            //calling constructor for hexagon
            AllShapes.push_back((Hexagon *)new Hexagon(id1, hexagon, side1));
            id1++;
        }
            
        else if (str1 == "square"){
            //calling constructor for square
            AllShapes.push_back((Square *)new Square(id1, square, side1));
            id1++;
        }
            
        else if (str1 == "circle"){
            //calling constructor for circle
            AllShapes.push_back((Circle *)new Circle(id1, circle, side1));
            id1++;
        }
        //taking again inputs
        cin >> str1;
    }
    cin >> id1;
    // For taking 0 after END
    char q;
    cin >> q;
    // q is query
    while (q != 'X')
    {
        if (q == 'P')
        {
            // printing ith id
            int i;
            cin >> i;
            //if size is out of bound
            if (i >= AllShapes.size())
                cout << -1 << endl;
            else
                display(AllShapes[i]);
            //if inside bound print
        }
        else if (q == 'A')
        {
            //printing display for highest area shape
            string st;
            cin >> st;
            double ar = -1.0;
            Shape *h_ar = nullptr; // check here;
            st[0] = toupper(st[0]);
            for (auto shp : AllShapes)
            {
                if (shp->getShapeName() == st)
                {
                    //if greater then maximize it 
                    if (shp->area() > ar)
                    {
                        ar = shp->area();
                        h_ar = shp;
                    }
                }
            }
            if (h_ar != nullptr)
                display(h_ar);
            else
                cout << -1 << endl;
        }
        else if (q == 'H')
        {
            // if it is circle then only maximize it
            Shape *h_ar = nullptr; // check here;
            double ar = -1;
            for (auto shp : AllShapes)
            {
                if (shp->area() > ar)
                {
                    ar = shp->area();
                    h_ar = shp;
                }
            }
            if (h_ar != nullptr)
                display(h_ar);
        }
        // take input again
        cin >> q;
    }
}
