// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 05
// Date: 27/02, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include "Shape.h"

// Return Id
int Shape ::getId()
{
    return id;
}

// Return shape_type
stype Shape ::getType()
{
    return shape_type;
}

// Return ShapeName
string Shape ::getShapeName()
{ // check here if doubt;
    return ShapeNames[this->shape_type];
}