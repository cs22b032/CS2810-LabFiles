// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 01
// Date: 23 , 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.

#include<bits/stdc++.h>
using namespace std;

class ComplexNum{
private:
    double real;
    double imag;
public:
    ComplexNum() : real(0.0), imag(0.0) {};
    ComplexNum(double a) : real(a), imag(0) {};
    ComplexNum(double a, double b) : real(a) , imag(b) {};
    ComplexNum(const ComplexNum& C1){
        this->real = C1.real;
        this->imag = C1.imag;
    }
    void copy(const ComplexNum& C1){
        this->real = C1.real;
        this->imag = C1.imag;
    }
    //for addition
    ComplexNum operator+(ComplexNum C2){
        return ComplexNum(this->real + C2.real, this->imag + C2.imag);
    }
    //for subtraction
    ComplexNum operator- (ComplexNum C2){
        return ComplexNum(this->real - C2.real, this->imag - C2.imag);
    }
    //for multiplication
    ComplexNum operator* (ComplexNum C2){
        double a1 = this->real;
        double b1 = this->imag;
        double a2 = C2.real;
        double b2 = C2.imag;
        ComplexNum r1 (a1 * a2 - b1*b2, a1*b2 + b1*a2);
        return r1;
    }
    //for division
    ComplexNum operator/ (ComplexNum C2){
        if(C2.imag == 0.0 && C2.real == 0.0) {
            ComplexNum v;
            v.real = 1;
            v.imag = 1;
            return v;
        }
        else{
        double a2 = C2.real;
        double b2 = (-1.0 )* C2.imag;
        ComplexNum e ;
        e.imag = this->imag;
        e.real = this->real;

        ComplexNum r3 (a2, b2);
            ComplexNum r2(e * r3);
            r2.imag /= (a2*a2 + b2*b2);
            r2.real /= (a2*a2 + b2*b2);
            return r2;
        }
    }
    friend ostream& operator<< (ostream& os, const ComplexNum C1);

};

ostream& operator<< (ostream& os, const ComplexNum C1){
    os << (int)C1.real <<" "<< (int)C1.imag ;
    return os;
}

int main(){
    int N;
    cin >> N;
    vector<ComplexNum> C;
    for(int i = 0; i < N; i++){
        int a, b;
        cin >> a >> b;
        ComplexNum r(a, b);
        C.push_back(r);
    }

    int Q;
    cin >> Q;
    while(Q--){
        char c;
        cin >> c;
        if(c == 'p'){
            int i;
            cin >> i;
            cout << C[i] << endl;
        }
        else{
            int i, j, k;
            cin >> i >> j >> k;
            
            if(c == 'a'){
                ComplexNum cp(C[i] + C[j]);
                C[k].copy(cp);
            }
            if(c == 's'){
                ComplexNum cp(C[i] - C[j]);
                C[k].copy(cp);
            }
            if(c == 'm'){
                ComplexNum cp(C[i] * C[j]);
                C[k].copy(cp);
            }
            if(c == 'd'){
                ComplexNum cp(C[i] / C[j]);
                C[k].copy(cp);
            }
        }
    }
}