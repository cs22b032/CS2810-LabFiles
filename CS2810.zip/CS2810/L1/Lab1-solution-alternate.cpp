#include<iostream>
#include<cstdio>
#include<cmath>
#include<iomanip>
#include<unistd.h>
#include<string>
#include<vector>

using namespace std;

class ComplexNum {

private:
    double real, imag;

public:
    ComplexNum()
    {
        real = imag = 0.0;
    }

    //Default is Rect. Coordinates, with only Real part.
    ComplexNum(double a)
    {
        real = a; imag = 0;
    }

    //Default is Rect. Coordinates
    ComplexNum(double a, double b)
    {
        real = a; imag = b;
    }

    ComplexNum(const ComplexNum &C1)
    {
        real = C1.real; imag = C1.imag;
    }

    ComplexNum operator+(ComplexNum const& C2)
    {
        ComplexNum Res;

        Res.real = real + C2.real;
        Res.imag = imag + C2.imag;

        return Res;
    }

    ComplexNum operator-(ComplexNum const& C2)
    {
        ComplexNum Res;

        Res.real = real - C2.real;
        Res.imag = imag - C2.imag;

        return Res;
    }

    // (a + b i) (c + di) = (ac - bd) + (bc + ad) i
    ComplexNum operator*(ComplexNum const& C2)
    {
        ComplexNum Res;

        Res.real = (real*C2.real - imag*C2.imag);
        Res.imag = (real*C2.imag + imag*C2.real);

        return Res;
    }

    //  (a + b i) / (c + d i) = (a + b i) * (c - d i) / (c^2 + d^2)
    ComplexNum operator / (ComplexNum const& C2)
    {
        ComplexNum Res;

        if(C2.real != 0 && C2.imag != 0){
            ComplexNum temp;
            double denom = (C2.real*C2.real + C2.imag*C2.imag);

            temp.real = C2.real;
            temp.imag = -C2.imag;

            Res = (*this) * temp;
            Res.real /= denom;
            Res.imag /= denom;
        }
        else{
            Res.real = 1.0;
            Res.imag = 1.0;
        }

        return Res;
    }

    void Print()
    {
        cout << setprecision(10);
        cout << real << " " << imag << endl;
    }

    friend ostream& operator<<(ostream& os, const ComplexNum& C1);
};

ostream& operator<<(ostream& os, const ComplexNum& C1)
{
    os << (int) C1.real << " " << (int) C1.imag;
    return os;
}

int main(int argc, char *argv[])
{
    vector<ComplexNum> C;
    int N, Q;

    cin >> N;
    C.resize(N);

    for (int i = 0; i < N; i++)
    {
        int a, b;
        cin >> a >> b;
        C[i] = ComplexNum(a, b);
        // C[i].Print();
    }

    cin >> Q;
    char q;
    for (int n = 0; n < Q; n++)
    {
        int i, j, k;
        cin >> q;

        switch (q)
    	{
        	case 'a':
                cin >> i >> j >> k;
                C[k] = C[i] + C[j];
                // C[k].Print();
                break;

        	case 's':
                cin >> i >> j >> k;
                C[k] = C[i] - C[j];
                // C[k].Print();
                break;

        	case 'm':
                cin >> i >> j >> k;
                C[k] = C[i] * C[j];
                // C[k].Print();
                break;

        	case 'd':
                cin >> i >> j >> k;
                C[k] = C[i] / C[j];
                // C[k].Print();
                break;

        	case 'p':
                cin >> i;
                // C[i].Print();
                cout << C[i] << endl;
                break;

        	default:
                break;
    	}
    }
}
