#include<ostream>
#include<fstream>
#include<vector>
#include<string>
#include<map>
#include<set>
#include<stack>
#include<queue>
#include <algorithm>
#include <iterator>
#include "Graph.h"
using namespace std;

#pragma once

class GraphAdjList: public Graph
{
 private:
  vector< map<int, int, less <int> > > AdjList;
  vector<int> indegree; // degree of each vertex
  vector<int> outdegree;
  
 public:
  GraphAdjList(int nc = 0, int ec = 0);
  GraphAdjList(const GraphAdjList& G1): Graph(0, 0)
  {
    *this = G1;
  }

  void addedge(int src, int dest, int weight);
  void deledge(int src, int dest);

  void DeleteNodeEdges(int m);

  // set<int> vcover_expon();
  // set<int> vcover_greedy();

  vector<int> augmentingPath(int src, int dest, int& min_wt);
  void printgraph();
  vector<map<int, int, less<int>>> FoldFrc(int src, int dest);
  // bool verifyVC(set<int> S);
  
};
