// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 10
// Date: 23/04, 2024, 2pm
// Question No. 1
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<map>
#include<stack>
#include<algorithm>
#include<iterator>
#include<cassert>
#include <stdlib.h>
#include <getopt.h>
#include "GraphAdjList.h"
using namespace std;



int main(int argc, char *argv[])
{
  ifstream ifile;
  ofstream ofile;
  int N;
  string alg;
  int src1, dest1;

  static struct option long_options[] =
  {
    {"in",  required_argument, 0, 'i'},
    {"out",  required_argument, 0, 'o'},
    {"alg", required_argument, 0, 'a'},
    {"src", required_argument, 0, 's'},
    {"dest", required_argument,0, 'd'},
    {0, 0, 0, 0}
  };
  
  while (1)
  {
    /* getopt_long stores the option index here. */
    int option_index = 0;
    int id;

    id = getopt_long (argc, argv, "i:o:a:s:d", long_options, &option_index);

    /* Detect the end of the options. */
    if (id == -1)
      break;

    switch (id)
    {
    case 'i':
      ifile.open(optarg, ios::in);
      break;

    case 'o':
      ofile.open(optarg, ios::out);
      break;

    case 'a':
      alg = string(optarg);
      break;

    case 's':
      src1 = stoi(optarg);
      break;
    case 'd':
      dest1 = stoi(optarg);
      break;

    case '?':
      /* getopt_long already printed an error message. */
      abort();
      break;

    default:
      abort ();
    }
  }
  cout << "arg passed " << endl;
  ifile >> N;
  GraphAdjList G(N);
  
  int src, dest, weight;
  
  while (ifile >> src >> dest >> weight)
  {
    G.addedge(src, dest, weight);
    // Make sure that bidirectional edges are added.
  }
  cout << "input read done" << endl;
  set<int> S;

  // if (alg == "grd")
  // {
  //   S.clear();
  //   S = G.vcover_greedy();
  //   for (auto ptr = S.begin(); ptr != S.end(); ptr++)
  //     ofile << *ptr << " ";
  //   ofile << endl;

  // }
  
  // if (alg == "exp")
  // {
  //   S.clear();
  //   S = G.vcover_expon();
  //   for (auto ptr = S.begin(); ptr != S.end(); ptr++)
  //     ofile << *ptr << " ";
  //   ofile << endl;
  // }
  vector<map<int, int>> ans = G.FoldFrc(src1, dest1);
  
}
