#include "GraphAdjList.h"

GraphAdjList::GraphAdjList(int nc, int ec) : Graph(nc, ec)
{
  AdjList.resize(nc);
  indegree.resize(nc);
  outdegree.resize(nc);
}

void GraphAdjList ::addedge(int src, int dest, int weight)
{
  int V = getnodecount();
  if (src >= V || dest >= V || src < 0 || dest < 0)
    return;
  if (src == dest)
    return;
  // if simple graph
  auto [it, success] = AdjList[src].insert(make_pair(dest, weight));
  // auto [it2, success2] = AdjList[dest].insert(make_pair(src, weight)); if directed comment this
  if (success)
  {
    outdegree[src]++;
    indegree[dest]++;
  }
  // if (success2)  //if directed comment this
  //   indegree[dest]++;
  if (success)
    setedgecount(getedgecount() + 1);
  // cout << "Adding edge " << "( " << src <<" ," << dest <<" )  with weight "<< weight << endl;
}

void GraphAdjList ::deledge(int src, int dest)
{
  int V = getnodecount();
  if (src >= V && dest >= V && src < 0 && dest < 0)
    return;
  auto it = AdjList[src].find(dest);
  // auto it1 = AdjList[dest].find(src);
  if (it != AdjList[src].end())
  {
    AdjList[src].erase(dest);
    outdegree[src]--;
    indegree[dest]--;
    setedgecount(getedgecount() - 1);
  }
  // if (it1 != AdjList[dest].end())
  // {
  //   AdjList[dest].erase(src);
  //   degree[dest]--;
  //   setedgecount(getedgecount() - 1);
  // }
}

void printv(vector<int> &vec)
{
  for (auto a : vec)
    cout << a << " ";
  cout << endl;
  return;
}

vector<int> GraphAdjList::augmentingPath(int src, int dest, int &min_weight)
{
  // printgraph();
  min_weight = INT_MAX;
  int V = getnodecount();
  if (src >= V || dest >= V || src < 0 || dest < 0)
    return vector<int>();
  // cout << "He" << endl;
  stack<int> path;
  vector<bool> visited(V);
  vector<int> ans;
  path.push(src);
  int edg = src;
  while (edg != dest)
  {
    int node = path.top();
    visited[node] = true;
    // if (visited[node] == true)
    if (outdegree[node] == 0)
    {
      path.pop();
      if (path.empty())
        return vector<int>();
      continue;
    }
    for (auto &adj : AdjList[node])
    {
      edg = (adj).first;
      if (visited[edg] == true)
      {
        edg = -1;
      }
      else
        break;
    }

    if (edg == -1)
    {
      path.pop();
      if (path.empty())
        return vector<int>();
      continue;
    }
    path.push(edg);
  }
  if (path.top() == dest)
  {
    while (!path.empty())
    {
      int a = path.top();
      ans.push_back(a);
      path.pop();
    }
    reverse(ans.begin(), ans.end());
    for (int i = 0; i < ans.size() - 1; i++)
    {
      min_weight = min(min_weight, AdjList[ans[i]][ans[i + 1]]);
    }
    cout << " Printing Path" << endl;
    printv(ans);
    cout << "minWT :" << min_weight << endl;
    return ans;
  }
  else
    return vector<int>();
}

void printset(set<int> &S)
{
  cout << "*** \t Printing set with size k: " << S.size() << endl;
  for (auto ptr = S.begin(); ptr != S.end(); ptr++)
    cout << *ptr << " ";
  cout << "\n***\n"
       << endl;
}

void GraphAdjList::DeleteNodeEdges(int m)
{
  // delete all ou
  //  if(m >=0 && m < getnodecount())
  for (auto edg : AdjList[m])
  {
    deledge(m, edg.first);
  }
  return;
}

void GraphAdjList::printgraph()
{
  int N = getnodecount();
  int E = getedgecount();

  cout << "\n** Printing graph **\n";

  cout << N << " " << E << endl;
  for (int node = 0; node < N; node++)
  {
    cout << "Degree of " << node << " is: " << -indegree[node] + outdegree[node] << endl;
    for (auto ptr = AdjList[node].begin(); ptr != AdjList[node].end(); ptr++)
    {
      cout << node << " " << ptr->first << " " << ptr->second << endl;
    }
  }

  cout << "\n** Printed graph **\n";
}

vector<map<int, int, less<int>>> GraphAdjList ::FoldFrc(const int src, const int dest)
{
  // printgraph();
  vector<map<int, int, less<int>>> ans;
  int minWT = 0;
  vector<int> agPath;
  GraphAdjList Gres(*this);
  GraphAdjList Gans(this->getnodecount());
  agPath = Gres.augmentingPath(src, dest, minWT);
  while (agPath != vector<int>())
  {
    for (int i = 1; i < agPath.size(); i++)
    {
      Gres.AdjList[agPath[i - 1]][agPath[i]] -= minWT;
      if (Gres.AdjList[agPath[i - 1]][agPath[i]] == 0)
        Gres.deledge(agPath[i - 1], agPath[i]);
      if (Gres.AdjList[agPath[i]].find(agPath[i - 1]) == Gres.AdjList[agPath[i]].end())
        Gres.addedge(agPath[i], agPath[i - 1], minWT);
        else
      Gres.AdjList[agPath[i]][agPath[i - 1]] += minWT;
      Gans.AdjList[agPath[i - 1]][agPath[i]] += minWT;
    }
    cout << "res";
    Gres.printgraph();
    // cout << "ans";
    // Gans.printgraph();
    agPath = Gres.augmentingPath(src, dest, minWT);
  }
  // cout << "he" << endl;
  int maxFlow = 0;
  for (int i = 0; i < Gans.getnodecount(); i++)
  {
    // for (auto &edg1 : Gans.AdjList[i])
    // {
    //   // if(this->AdjList[i].find(edg1.first) == AdjList[i].end()) 
    //   // {
    //   //   Gans.AdjList[edg1.first][i] -= edg1.second;
    //   //   // Gans.deledge(i, edg1.first);
    //   //   continue;
    //   // }
    //   if (edg1.second == 0)
    //     Gans.deledge(i, edg1.first);
    //   if (Gans.AdjList[i][edg1.first] == Gans.AdjList[edg1.first][i])
    //   {
    //     Gans.deledge(i, edg1.first);
    //     Gans.deledge(edg1.first, i);
    //   }
    // }
  }
  for (auto adj : Gans.AdjList[src])
  {
    maxFlow += adj.second;
  }
  Gans.printgraph();
  cout << maxFlow << endl;
  ans = Gans.AdjList;
  return ans;
}

// int main()
// {
//   GraphAdjList G(6);

//   G.addedge(0, 1, 1);
//   G.addedge(0, 2, 2);
//   G.addedge(1, 3, 3);
//   G.addedge(1, 4, 4);
//   G.addedge(2, 3, 7);
//   G.addedge(3, 5, 6);
//   G.addedge(4, 5, 5);
//   //     G.addedge(1, 3, 4);
//   //     G.addedge(2, 4, 7);
//   //     G.addedge(3, 4, 8);
//   //     G.addedge(2, 3, 10);
//   //     G.addedge(4, 1, 9);
//   //     G.deledge(2, 3);
//   //     G.deledge(1, 4);
//   G.printgraph();
//   set<int> S = G.vcover_greedy();

//   //     // G.kruskal();
//   //     // G.prim();
//   //     // G.dijkstra(0, 3);
//     for (auto ptr = S.begin(); ptr != S.end(); ptr++)
//       cout << *ptr << " ";
//     cout << endl;
// }

// 6
// 2 0 1 1
// 3 0 2 2
// 4 1 3 3
// 5 1 4 4
// 6 2 3 7
// 7 3 5 6
// 8 4 5 5