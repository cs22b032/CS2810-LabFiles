#include "Faculty.h"
// To compile this separately, use g++ -c -o Faculty.o Faculty.cpp

// Assigned respectively.
// gradepoint field is set to 0 for Faculty's Course objects
// and is not used.

Faculty::Faculty(unsigned int sad, string naam,
		 vector<Course> C, unsigned int jo, unsigned int co): 
  Person(sad, naam)
{

  //  cout << sad << " " << C.size() << " Creating Faculty\n";

  CoursesTaught = vector<Course>(C.size());
  
  for (int i = 0; i < C.size(); i++)
    {
      CoursesTaught[i] = C[i];
      CoursesTaught[i].SetGrade(0);
    }
  journals = jo;
  confs = co;

  //  cout << sad << " Created Faculty\n";
}

// Returns journals value
unsigned int Faculty::GetJournals()
{
  return journals;
}

// Returns confs value
unsigned int Faculty::GetConfs()
{
  return confs;
}

// can use any one of the following two
// Returns copy of courses vector
vector<Course> Faculty::GetCourses()
{
  return CoursesTaught;
}

// Returns ref. to courses vector
// const vector<Course>& Faculty::GetCourses()
// {
//   return CoursesTaught;
// }

// Prints sadhar, name, journals, conferences
// on one line separated by a space.
void Faculty::Print() 
{
  Person::Print();
  cout << " " << journals << " " << confs << endl;
}
