#include<iostream>
#include "Course.h"
#include "Person.h"
#include "Faculty.h"
#include "Student.h"

bool isStudentPresent(unsigned int sid, vector<Student> &SV){
    bool ans = false;

    for (int i = 0; i < SV.size(); i++) {
        if (SV[i].GetId() == sid) {
            ans = true;
            break;
        }
    }
    return ans;
}

bool isFacultyPresent(unsigned int fid, vector<Faculty> &FV){
    bool ans = false;

    for (int i = 0; i < FV.size(); i++) {
        if (FV[i].GetId() == fid) {
            ans = true;
            break;
        }
    }
    return ans;
}

int main() {
    vector<Faculty> FVector;
    vector<Student> SVector;

    int F, S;
    unsigned int sid, fid, cid, N, journals, confs, grade;
    string name;

    cin >> F >> S;

    for (int i = 0; i < F; i++) {        
        vector<Course> Taught;

        cin >> fid >> name >> N;
        // cout << "Creating Vector Entity for " << id << " " << name << endl; 
        Taught.resize(N);

        for (int k = 0; k < N; k++) {
            cin >> cid;
            Taught[k] = Course(cid, 0);
            //	  cout << cid << " Reached after Taught\n" ;
        }

        cin >> journals >> confs;
        
        // Ignore already processed faculty id
        if(!isFacultyPresent(fid, FVector)) FVector.push_back(Faculty(fid, name, Taught, journals, confs));
    }

    for (int i = 0; i < S; i++) {
        vector<Course> Taken;

        cin >> sid >> name >> N;

        Taken.resize(N);

        for (int k = 0; k < N; k++) {
            cin >> cid >> grade;
            Taken[k] = Course(cid, grade);
            //	  cout << cid << " Reached after Taken\n" ;
        }

        cin >> fid;

        // Ignore already processed student id
        if(!isStudentPresent(sid, SVector)) SVector.push_back(Student(sid, name, Taken, fid));
    }

    char Q;

    cin >> Q;
    while (Q != 'X') {
        switch (Q) {
            case 'P':
                cin >> sid;
                for (int k = 0; k < SVector.size(); k++) {
                    if (SVector[k].GetId() == sid) {
                        SVector[k].Print();
                        break;
                    }
                } // End For
                break; // End 'P' query

            case 'K':
                cin >> fid;
                for (int k = 0; k < FVector.size(); k++) {
                    if (FVector[k].GetId() == fid) {
                        FVector[k].Print();
                        break;
                    }
                } // End For
                break; // End 'K' query

            case 'H':
                unsigned int maxJ, max_fid;

                maxJ = FVector[0].GetJournals();
                max_fid = FVector[0].GetId();
                for (int k = 1; k < FVector.size(); k++) {
                    if (FVector[k].GetJournals() > maxJ) {
                        maxJ = FVector[k].GetJournals();
                        max_fid = FVector[k].GetId();
                    }
                } // End For
                cout << max_fid << endl;
                break; // End 'H' query

            case 'M':
                cin >> fid;

                if(isFacultyPresent(fid, FVector)) { // Valid fid
                    unsigned int count = 0;

                    for (int k = 0; k < SVector.size(); k++) {
                        if (SVector[k].GetFacad() == fid) {
                            count++;
                        }
                    } // End For
                    cout << count << endl;
                }
                break; // End 'M' query
        }

        cin >> Q;
    } // End While
}