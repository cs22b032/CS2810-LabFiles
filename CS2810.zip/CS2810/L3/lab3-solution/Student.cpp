#include "Student.h"

// Assigned respectively.
Student::Student(unsigned int sad, string naam,
		 vector<Course> C, unsigned int fid):
  Person(sad, naam), facad(fid)
{
  int temp = 0;

  //  cout << sad << " " << C.size() << " Creating Student\n";

  CoursesTaken = vector<Course>(C.size());

  for (unsigned int i = 0; i < CoursesTaken.size(); i++)
    {
      CoursesTaken[i] = C[i];
      temp += CoursesTaken[i].GetGrade();
    }
  
  cgpa = (unsigned int) temp / CoursesTaken.size();

  //  cout << sad << " " << C.size() << " Created Student\n";
}

// Returns copy of courses vector
vector<Course> Student::GetCourses()
{
  return CoursesTaken;
}

// Returns  copy of Facad object of student.
unsigned int Student::GetCG()
{
  return cgpa;
}

unsigned int Student::GetFacad() 
{
  return facad;
}
// Prints sadhar, name, cpga details of student,
// followed by facad's id and name.

void Student::Print()
{
  Person::Print();
  cout << " " << cgpa << " " << facad << endl;
}
