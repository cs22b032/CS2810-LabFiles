// To compile this separately, use g++ -c -o Person.o Person.cpp
#include "Person.h"

Person::Person(unsigned int sad, string naam) // assigned respectively
{
  sadhar = sad;
  name = naam;
  //  cout << sad << " Created Person\n";
}

string Person::GetName()
{
  return name;
}

unsigned int Person::GetId()
{
  return sadhar;
}

// Prints id and name separated by a blank space on
// one line.
  
void Person::Print()
{
  cout << sadhar << " " << name;
}
