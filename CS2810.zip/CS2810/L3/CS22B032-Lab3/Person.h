// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 3
// Date: 06/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

using namespace std;

#pragma once
class Person
{

 private:

  unsigned int sadhar;
  string name;

 public:
  
  Person(unsigned int sad, string naam); // assigned respectively

  string GetName();

  unsigned int GetId();
  
  void Print(); // Prints id and name separated by a blank space on
                  // one line.
};

// #include "Person.cpp"