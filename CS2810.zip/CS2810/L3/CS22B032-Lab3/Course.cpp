// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 3
// Date: 06/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate

#include <iostream>
#include <cassert>
#include "Course.h"

using namespace std;

Course :: Course() { //default constructer
    cid = 0;
    gradepoint = 0;
}

Course :: Course(unsigned int id = 0, unsigned int grade = 0){
    if(grade <= 10 && grade >= 4) gradepoint = grade;
    if(id <= 100 && id >= 999) cid = id;
}

unsigned int Course:: GetCid() {
    return cid;
}

unsigned int Course:: GetGrade() {
    return gradepoint;
}

void Course::SetGrade(int g){
    if(g <= 10 && g >= 4) gradepoint = g;
}

void Course :: Print(){
    cout << cid << " " << gradepoint;
}
