// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 3
// Date: 06/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include<bits/stdc++.h>
using namespace std;
#include "Faculty.h"
#include "Student.h"
#include "Person.h"
#include "Course.h"

int main(){
    //the number of Faculty members (F), and the number of Students (S)
    int F, S;
    cin >> F >> S;
    vector<Faculty> fac;
    vector<Student> stud;
    //for F faculty
    for(int i = 0; i < F; i++){
        int id, N;
        string per;
        vector<Course> c;
        unsigned int J, C;
        cin >> id >> per >> N;
        //N courses with grades 0
        for(int j = 0; j < N; j++){
            unsigned int cous ;
            cin >> cous;
            c.push_back(Course(cous, 0));
        }
        cin >> J >> C;//Faculty :: Faculty(unsigned int sad, string naam,
	                    //vector<Course> C, unsigned int jo, unsigned int co) 
        fac.push_back(Faculty(id, per, c, J , C));
    }
    //for S Student
        //id name N uint1 gp1 uint2 gp2 ... uintN gpN J C fid
    for(int i = 0; i< S;i++){
        int id, N;
        string per;
        vector<Course> c;
        unsigned int fid;
        cin >> id >> per >> N;
        // N courses with course name and gp
        for(int j = 0; j < N ; j++){
            unsigned int cous, gp;
            cin >> cous >> gp;
            c.push_back(Course(cous, gp));
        }
        cin >> fid;
        stud.push_back(Student(id, per, c, fid));
    }
    // for(auto it : fac){
    //     it.Print() ;
    //     cout << endl;
    // }
    // cout << endl;
    // for(auto it : stud){
    //     it.Print() ;
    //     cout << endl;
    // }
    char Q;
    cin >> Q;

    while(Q != 'X'){// p, k , h, m
        if(Q == 'P'){
            //print student details
            int id;
            cin >> id;
            for(auto st : stud){
                if(st.GetId() == id) 
                    st.Print();
            }
        }
        else if(Q =='K'){
            //print 
            int id;
            cin >> id;
            for(auto fc : fac){
                if(fc.GetId() == id) 
                    fc.Print();
            }
        }
        else if(Q== 'H'){
            unsigned int ans = 0;
            for(auto fc : fac){
                ans = max(fc.GetJournals() , ans) ;
            }
            for(auto fc : fac){
                if(fc.GetJournals() == ans) 
                {
                    cout <<fc.GetId() << endl;
                    break;
                }
            }
            //cout << ans << endl;
        }
        else if(Q == 'M'){
            unsigned int fd = 0;
            unsigned int facad ;
            cin >> facad;
            for(auto st : stud){
                if(st.GetFacad() == facad) fd++;
            }
            if(fd != 0) cout << fd << endl;
        }
        cin >> Q;
    }
}