// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 3
// Date: 06/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include "Person.h"
#include "Course.h"
#include "Faculty.h"

#pragma once
class Student: public Person
{
  
 private:
  vector<Course> CoursesTaken;
  unsigned int cgpa; // Integer part of the average gradepoints of
                     // all Courses in CoursesTaken vector.
                     // 9, 9, 8: avg = 8.67 = 8
  unsigned int facad;
  
 public:
  Student(unsigned int sad, string naam,
	  vector<Course> C, unsigned int fid);
    // Assigned respectively.
    
  vector<Course> GetCourses(); // Returns copy of courses vector
  unsigned int GetCG();
  unsigned int GetFacad(); // Returns  copy of Facad ID of student.
  void Print(); // Prints sadhar, name, cpga details of student,
                // followed by facad's id and name.
};

// #include "Student.cpp"