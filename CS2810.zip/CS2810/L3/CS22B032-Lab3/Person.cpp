// Roll Number: CS22B032
// Name: Ankit Raj
// CS2810 Lab Number: 3
// Date: 06/02, 2024, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "Person.h"

using namespace std;

  
Person :: Person(unsigned int sad, string naam){
    sadhar = sad;
    name = naam;
} // assigned respectively

string Person :: GetName(){
    return name;
}

unsigned int Person :: GetId(){
    return sadhar;
}

void Person :: Print(){
    cout << sadhar << " " << name ;
} // Prints id and name separated by a blank space on
// one line.

